import random
from typing import Dict, Any, Tuple, List

# --- Constantes do Jogo ---
SIMULACOES_TOTAIS = 30000 
CICLOS_MAXIMOS = 3
HP_INICIAL = 30
UTILIDADE_MORTE = -1000
UTILIDADE_SOBREVIVENCIA_BASE = 1000
BONUS_CORAGEM = 100
SIMULACOES_SOMBRA = 50 # Simulações para o lookahead da IA (Minimax probabilístico)

ACOES: Dict[str, Dict[str, int]] = {
    "Fuga Desesperada": {"mod_eco": 2, "mod_sombra": -2, "limiar_resiliencia": 12},
    "Sombra Silenciosa": {"mod_eco": -1, "mod_sombra": 2, "limiar_resiliencia": 8},
    "Confronto Direto": {"mod_eco": 1, "mod_sombra": -1, "limiar_resiliencia": 10},
}

# --- Funções Auxiliares de Lógica ---

def calcular_dano_sombra(rolagem_efetiva: int, postura: str) -> int:
    """Calcula o dano infligido pela Sombra com base na rolagem efetiva e postura."""
    if postura == "Agressiva":
        if rolagem_efetiva >= 19:
            return float('inf')  # Morte Instantânea
        elif rolagem_efetiva >= 13:
            return 8
        elif rolagem_efetiva >= 7:
            return 4
    elif postura == "Cautelosa":
        if rolagem_efetiva >= 20:
            return float('inf')  # Morte Instantânea
        elif rolagem_efetiva >= 15:
            return 5
        elif rolagem_efetiva >= 9:
            return 2
    return 0

def decisao_sombra(mod_sombra: int) -> str:
    """
    A Sombra escolhe a postura (Agressiva/Cautelosa) que maximiza o dano médio.
    Isto é um Minimax (minimizar a utilidade do jogador = maximizar o dano da Sombra).
    """
    posturas = ["Agressiva", "Cautelosa"]
    danos_medios: Dict[str, float] = {}

    for postura in posturas:
        dano_acumulado = 0
        for _ in range(SIMULACOES_SOMBRA):
            d20 = random.randint(1, 20)
            rolagem_efetiva = d20 - mod_sombra
            dano = calcular_dano_sombra(rolagem_efetiva, postura)
            
            # Penaliza drasticamente a morte instantânea nas médias
            if dano == float('inf'):
                dano_acumulado += 50 # Um valor alto para penalizar o jogador na média
            else:
                dano_acumulado += dano
        
        danos_medios[postura] = dano_acumulado / SIMULACOES_SOMBRA

    # A Sombra escolhe a postura que tem a MAIOR média de dano
    return max(danos_medios, key=danos_medios.get)

def heuristica_jogador_adaptativa(hp: int, eco: int) -> str:
    """Heurística simples para ciclos 2 e 3."""
    if hp <= 10 or eco >= 4:
        return "Sombra Silenciosa"
    if hp >= 25:
        return "Fuga Desesperada"
    return "Confronto Direto"

def calcular_utilidade_final(hp: int, coragem: int, desfecho: str) -> float:
    """Calcula a utilidade com base no desfecho."""
    if desfecho in ["DERROTA", "COLAPSO"]:
        return UTILIDADE_MORTE
    
    # VITÓRIA ou FIM_DE_JOGO (sobrevivência)
    return float(UTILIDADE_SOBREVIVENCIA_BASE + hp + (BONUS_CORAGEM * coragem))

# --- Função de Simulação de Ciclo ---

def simular_ciclo(estado: Dict[str, Any], acao_escolhida: str, usar_coragem: bool) -> Tuple[Dict[str, Any], str]:
    """Simula um único ciclo do jogo."""
    
    info_acao = ACOES[acao_escolhida]
    
    # 0. Uso de Fragmento de Coragem
    bonus_resiliencia = 0
    if usar_coragem and estado['fragmentos_coragem'] > 0:
        bonus_resiliencia = 5
        estado['fragmentos_coragem'] -= 1
    
    # 1. Atualização do Eco
    estado['eco_mortal'] = max(0, estado['eco_mortal'] + info_acao['mod_eco'])
    
    # 2. Teste de Resiliência
    d20_resistencia = random.randint(1, 20)
    
    if d20_resistencia >= 20:
        return estado, "VITORIA" # Fuga instantânea
    
    if d20_resistencia == 19:
        estado['fragmentos_coragem'] += 1
    
    if d20_resistencia <= 3:
        return estado, "COLAPSO" # Falha crítica (morte)

    # Limiar ajustado pelo Eco e bônus de Coragem
    limiar_efetivo = info_acao['limiar_resiliencia'] - estado['eco_mortal'] - bonus_resiliencia
    
    if d20_resistencia < limiar_efetivo:
        estado['hp'] -= 10 # Dano ambiental (falha parcial)
        if estado['hp'] <= 0:
            return estado, "COLAPSO"

    # Se HP > 0, o jogo continua para o Ataque da Sombra
    
    # 3. Ataque da Sombra Adaptativa
    
    # Lógica de Decisão da Sombra (Minimax Probabilístico)
    postura = decisao_sombra(info_acao['mod_sombra'])
    
    # Rolagem de Ataque Real
    d20_ataque = random.randint(1, 20)
    rolagem_efetiva = d20_ataque - info_acao['mod_sombra']
    dano_sombra = calcular_dano_sombra(rolagem_efetiva, postura)
    
    if dano_sombra == float('inf'):
        return estado, "COLAPSO" # Morte instantânea
        
    estado['hp'] -= dano_sombra
    
    if estado['hp'] <= 0:
        return estado, "COLAPSO"
    
    return estado, "CONTINUA"

# --- Função de Simulação Completa ---

def simular_partida(acao_inicial: str) -> Tuple[float, bool]:
    """Simula uma partida completa de 3 ciclos, com IA adaptativa."""
    
    estado: Dict[str, Any] = {
        'hp': HP_INICIAL,
        'eco_mortal': 0,
        'fragmentos_coragem': 0
    }
    
    # 1. Ciclo Inicial (Ação Fixa)
    acao = acao_inicial
    
    # Coragem é usada se o limiar for alto (12 ou 10) E houver coragem (apenas tentativa, coragem = 0)
    # Neste ponto, coragem é 0, então não será usada.
    estado, desfecho = simular_ciclo(estado, acao, False) 
    
    if desfecho in ["VITORIA", "COLAPSO"]:
        sobreviveu = (desfecho == "VITORIA")
        return calcular_utilidade_final(estado['hp'], estado['fragmentos_coragem'], desfecho), sobreviveu

    # 2. Ciclos Subsequentes (Ação Adaptativa)
    for ciclo in range(2, CICLOS_MAXIMOS + 1):
        
        # Heurística para a ação
        acao = heuristica_jogador_adaptativa(estado['hp'], estado['eco_mortal'])
        
        # Heurística para Coragem: Usar se a ação for arriscada (Fuga ou Confronto) e se HP estiver baixo.
        usar_coragem = (acao != "Sombra Silenciosa" and estado['hp'] <= 20 and estado['fragmentos_coragem'] > 0)
        
        estado, desfecho = simular_ciclo(estado, acao, usar_coragem)

        if desfecho in ["VITORIA", "COLAPSO"]:
            sobreviveu = (desfecho == "VITORIA")
            return calcular_utilidade_final(estado['hp'], estado['fragmentos_coragem'], desfecho), sobreviveu
            
    # Fim dos 3 ciclos
    sobreviveu = True
    return calcular_utilidade_final(estado['hp'], estado['fragmentos_coragem'], "FIM_DE_JOGO"), sobreviveu

# --- Execução Principal (Monte Carlo) ---

resultados_finais: Dict[str, Dict[str, float]] = {}

print(f"Iniciando Simulação  com {SIMULACOES_TOTAIS} iterações por ação inicial...")
print("--------------------------------------------------")

for acao_inicial_teste in ACOES.keys():
    
    utilidade_total = 0.0
    vitorias_count = 0
    
    for _ in range(SIMULACOES_TOTAIS):
        utilidade, sobreviveu = simular_partida(acao_inicial_teste)
        utilidade_total += utilidade
        if sobreviveu:
            vitorias_count += 1
            
    utilidade_media = utilidade_total / SIMULACOES_TOTAIS
    taxa_sobrevivencia = (vitorias_count / SIMULACOES_TOTAIS) * 100
    
    resultados_finais[acao_inicial_teste] = {
        "utilidade_media": utilidade_media,
        "taxa_sobrevivencia": taxa_sobrevivencia
    }
    
    print(f"Ação Inicial: {acao_inicial_teste}")
    print(f"  -> Utilidade Média: {utilidade_media:,.2f} pontos")
    print(f"  -> Taxa de Sobrevivência: {taxa_sobrevivencia:.2f}%")

print("--------------------------------------------------")

# Determinar a melhor ação
melhor_acao = max(resultados_finais, key=lambda x: resultados_finais[x]["utilidade_media"])
melhor_utilidade = resultados_finais[melhor_acao]["utilidade_media"]

print(f"\nANÁLISE FINAL: A melhor ação inicial é '{melhor_acao}'")
print(f"com uma utilidade média esperada de {melhor_utilidade:,.2f} pontos.")