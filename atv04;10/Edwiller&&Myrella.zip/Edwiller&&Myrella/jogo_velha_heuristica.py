import random

# --- Variáveis Globais e Configuração ---
# Tamanho do tabuleiro e símbolos dos jogadores
TAMANHO_TABULEIRO = 9
JOGADOR_HUMANO = 'X'
JOGADOR_IA = 'O'

# Combinações de vitória: Linhas, Colunas, Diagonais (índices 0-8)
COMBINACOES_VITORIA = [
    (0, 1, 2), (3, 4, 5), (6, 7, 8),  # Linhas
    (0, 3, 6), (1, 4, 7), (2, 5, 8),  # Colunas
    (0, 4, 8), (2, 4, 6)              # Diagonais
]

# --- Funções do Jogo ---

def criar_tabuleiro():
    """Retorna um tabuleiro vazio representado por uma lista de espaços."""
    return [' '] * TAMANHO_TABULEIRO

def exibir_tabuleiro(t):
    """Exibe o tabuleiro atual no console de forma formatada."""
    print(f"\n| {t[0]} | {t[1]} | {t[2]} |")
    print("-----------")
    print(f"| {t[3]} | {t[4]} | {t[5]} |")
    print("-----------")
    print(f"| {t[6]} | {t[7]} | {t[8]} |\n")

def verificar_vitoria(t, j):
    """Verifica se o jogador 'j' venceu no tabuleiro 't'."""
    return any(t[a] == t[b] == t[c] == j for a, b, c in COMBINACOES_VITORIA)

def movimentos_validos(t):
    """Retorna uma lista dos índices das posições vazias."""
    return [i for i, casa in enumerate(t) if casa == ' ']

# --- Lógica da IA (Heurística de 1 Nível) ---

def movimento_ia(t):
    """
    Implementa a heurística:
    1. Tenta vencer.
    2. Tenta bloquear o humano.
    3. Escolhe aleatoriamente.
    """
    validos = movimentos_validos(t)

    # 1. Tentar Vencer e 2. Tentar Bloquear
    for simbolo_alvo in [JOGADOR_IA, JOGADOR_HUMANO]:
        for i in validos:
            t[i] = simbolo_alvo # Simula a jogada
            if verificar_vitoria(t, simbolo_alvo):
                t[i] = ' '      # Desfaz a simulação
                if simbolo_alvo == JOGADOR_IA:
                    return i    # Retorna para vencer
                else:
                    return i    # Retorna para bloquear
            t[i] = ' '          # Desfaz a simulação

    # 3. Jogada Aleatória (se não houver vitória ou bloqueio imediato)
    return random.choice(validos) if validos else -1

# --- Função Principal do Jogo ---

def jogar():
    """Gerencia o fluxo principal do Jogo da Velha."""
    tabuleiro = criar_tabuleiro()
    turno = JOGADOR_HUMANO
    print("Jogo da Velha: Você é 'X', IA é 'O'. Posições de 1 a 9.")

    while True:
        exibir_tabuleiro(tabuleiro)
        
        if not movimentos_validos(tabuleiro):
            print("Fim de jogo! EMPATE!")
            break

        if turno == JOGADOR_HUMANO:
            try:
                # Entrada do Humano (posição de 1 a 9)
                pos = int(input(f"Sua vez ({JOGADOR_HUMANO}). Posição (1-9): ")) - 1
                if pos in movimentos_validos(tabuleiro):
                    tabuleiro[pos] = JOGADOR_HUMANO
                else:
                    print("Movimento inválido. Tente novamente.")
                    continue
            except ValueError:
                print("Entrada inválida. Digite um número.")
                continue
        else:
            # Movimento da IA
            print(f"Vez da IA ({JOGADOR_IA})...")
            pos = movimento_ia(tabuleiro)
            if pos != -1:
                tabuleiro[pos] = JOGADOR_IA

        # Verifica vitória após o movimento
        if verificar_vitoria(tabuleiro, turno):
            exibir_tabuleiro(tabuleiro)
            print(f"Fim de jogo! O jogador {turno} VENCEU!")
            break
            
        # Troca de turno
        turno = JOGADOR_IA if turno == JOGADOR_HUMANO else JOGADOR_HUMANO

if __name__ == "__main__":
    jogar()