import heapq
import random

# --- CONFIGURAÇÕES INICIAIS ---
HP_INICIAL = 30
acoes = ["Risky Escape", "Stealth", "Fight"]

# Heurística simples: quanto maior o HP, mais promissora é a ação
def heuristica(hp):
    return hp

# Função para calcular a utilidade final
def calcular_utilidade(sobrevive, hp_final, perdeu_membro):
    if not sobrevive:
        return -1000
    utilidade = 1000 + hp_final
    if perdeu_membro:
        utilidade -= 150
    return utilidade

# Função para simular rolagem de d20
def rolar_d20():
    return random.randint(1, 20)

# Função para executar uma ação e calcular utilidade e status
def simular_acao(acao, hp_atual):
    perdeu_membro = False
    sobrevive = True
    threat = 0

    # Ajuste de ameaça baseado na ação
    if acao == "Stealth":
        hp_atual = 20
    if acao == "Risky Escape":
        threat += 2
    elif acao == "Fight":
        threat += 2

    # Monstros reagem de forma competitiva: sempre +1 threat
    threat += 1  

    # Rola primeiro d20 (sobrevivência)
    d1 = rolar_d20()
    if d1 == 14:
        sobrevive = True
    elif d1 == 10:
        perdeu_membro = True
    elif d1 < 10:
        return calcular_utilidade(False, 0, False), "Morto"

    # Rola segundo d20 (ataque dos monstros)
    d2 = rolar_d20()
    dano = 0
    if d2 == 6:
        dano = 2 + threat
    elif d2 == 10:
        dano = 5 + threat
    elif d2 == 20:
        return calcular_utilidade(False, 0, False), "Morto"

    hp_final = max(0, hp_atual - dano)
    utilidade = calcular_utilidade(sobrevive, hp_final, perdeu_membro)

    # Determina status
    if utilidade <= -1000 or hp_final <= 0:
        status = "Morto"
    elif perdeu_membro:
        status = f"Vivo, mas perdeu um membro (HP={hp_final})"
    else:
        status = f"Vivo (HP={hp_final})"

    return utilidade, status

# --- A* adaptado para escolher melhor ação ---
def a_star_caverna(hp_inicial):
    fila = []
    for acao in acoes:
        utilidade, status = simular_acao(acao, hp_inicial)
        f = -utilidade + heuristica(hp_inicial)
        heapq.heappush(fila, (f, utilidade, [acao], status))

    melhor = heapq.heappop(fila)
    return melhor

# --- EXECUÇÃO ---
print("O aventureiro inicia com HP =", HP_INICIAL)
f, utilidade, caminho, status = a_star_caverna(HP_INICIAL)
print("Melhor decisão encontrada pelo A*:", caminho[0])
print("Utilidade obtida:", utilidade)
print("Status do jogador:", status)