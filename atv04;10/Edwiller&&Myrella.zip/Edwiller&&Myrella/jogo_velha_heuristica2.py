import random

JOGADOR_HUMANO, JOGADOR_IA, TAMANHO = 'X', 'O', 3
TOTAL = TAMANHO**3

# Cria todas as combinações vencedoras 3D
def get_vitorias():
    idx = range(TAMANHO)
    v = []
    for c in idx:
        for r in idx:
            v.append([(c,r,col) for col in idx])   # linhas
            v.append([(c,lin,r) for lin in idx])   # colunas
            v.append([(cam,r,c) for cam in idx])   # profundidades
        v.append([(c,i,i) for i in idx])           # diagonal camada
        v.append([(c,i,TAMANHO-1-i) for i in idx])
    # Grandes diagonais do cubo
    v += [[(i,i,i) for i in idx],
          [(i,TAMANHO-1-i,i) for i in idx],
          [(i,i,TAMANHO-1-i) for i in idx],
          [(i,TAMANHO-1-i,TAMANHO-1-i) for i in idx]]
    # Diagonais transversais
    for r in idx:
        v.append([(i,r,i) for i in idx])
        v.append([(i,r,TAMANHO-1-i) for i in idx])
    for c in idx:
        v.append([(i,i,c) for i in idx])
        v.append([(i,TAMANHO-1-i,c) for i in idx])
    return v

VITORIAS = get_vitorias()

# Converte coords 3D -> índice 1D
def c2i(c,r,col): return c*TAMANHO*TAMANHO + r*TAMANHO + col

# Funções principais
def criar_tabuleiro(): return [' ']*TOTAL
def exibir_tabuleiro(t):
    print("\n--- Jogo da Velha 3D ---")
    for c in range(TAMANHO):
        print(f"\n--- CAMADA {c+1} ---")
        for r in range(TAMANHO):
            linha = [f'{t[c2i(c,r,col)] if t[c2i(c,r,col)]!=" " else f"{c+1},{r+1},{col+1}":^6}' for col in range(TAMANHO)]
            print('|'+ '|'.join(linha)+'|')

def verificar_vitoria(t,j):
    for tri in VITORIAS:
        if all(t[c2i(c,r,col)]==j for c,r,col in tri): return True
    return False

def movimentos_validos(t):
    return [(c,r,col) for c in range(TAMANHO) for r in range(TAMANHO) for col in range(TAMANHO) if t[c2i(c,r,col)]==' ']

def movimento_ia(t):
    validos = movimentos_validos(t)
    if not validos: return None
    for simbolo in [JOGADOR_IA,JOGADOR_HUMANO]:
        for c,r,col in validos:
            t[c2i(c,r,col)] = simbolo
            if verificar_vitoria(t,simbolo):
                t[c2i(c,r,col)]=' '
                return (c,r,col)
            t[c2i(c,r,col)]=' '
    return random.choice(validos)

def jogar():
    t, turno = criar_tabuleiro(), JOGADOR_HUMANO
    print("\nVocê é 'X', IA é 'O'. Formato: C,L,C (1-3)")
    while True:
        exibir_tabuleiro(t)
        if not movimentos_validos(t) and not verificar_vitoria(t,JOGADOR_HUMANO) and not verificar_vitoria(t,JOGADOR_IA):
            print("Empate 3D!"); break
        if turno==JOGADOR_HUMANO:
            while True:
                try:
                    c,r,col = map(int,input(f"Sua vez ({JOGADOR_HUMANO}): ").split(','))
                    c,r,col = c-1,r-1,col-1
                    if 0<=c<3 and 0<=r<3 and 0<=col<3 and t[c2i(c,r,col)]==' ':
                        t[c2i(c,r,col)] = JOGADOR_HUMANO; break
                    else: print("Inválido ou ocupado.")
                except: print("Formato errado, ex: 1,2,3")
        else:
            print(f"IA ({JOGADOR_IA}) jogando...")
            c,r,col = movimento_ia(t)
            if c is not None:
                t[c2i(c,r,col)] = JOGADOR_IA
                print(f"IA jogou: Camada {c+1}, Linha {r+1}, Coluna {col+1}")
        if verificar_vitoria(t,turno):
            exibir_tabuleiro(t)
            print(f"\nFim! {turno} venceu o 3D!")
            break
        turno = JOGADOR_IA if turno==JOGADOR_HUMANO else JOGADOR_HUMANO

if __name__=="__main__":
    jogar()
