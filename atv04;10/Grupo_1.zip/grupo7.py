import heapq

# Definição do labirinto
labirinto = [
    [0, 2, 0, 0, 1, 0],
    [0, 1, 1, 0, 2, 0],
    ['S', 0, 0, 2, 0, 'G'],
    [0, 1, 0, 0, 0, 0]
]

# Custos dos tipos de célula
CUSTO = {
    0: 1,  # Caminho livre
    2: 5,  # Armadilha
    1: float('inf'),  # Parede (intransponível)
    'S': 1,
    'G': 1
}

# Movimentos possíveis: cima, baixo, esquerda, direita
MOVIMENTOS = [(-1, 0), (1, 0), (0, -1), (0, 1)]

# Função para encontrar as posições de S e G
def encontrar_inicio_e_meta(labirinto):
    for i in range(len(labirinto)):
        for j in range(len(labirinto[0])):
            if labirinto[i][j] == 'S':
                inicio = (i, j)
            elif labirinto[i][j] == 'G':
                meta = (i, j)
    return inicio, meta

# Heurística: Distância de Manhattan
def heuristica(pos, meta):
    return abs(pos[0] - meta[0]) + abs(pos[1] - meta[1])

# A* Search
def a_estrela(labirinto):
    inicio, meta = encontrar_inicio_e_meta(labirinto)
    fila = []
    heapq.heappush(fila, (0 + heuristica(inicio, meta), 0, inicio, [inicio]))  # (f, g, posição, caminho)

    visitados = set()

    while fila:
        f, g, atual, caminho = heapq.heappop(fila)

        if atual in visitados:
            continue
        visitados.add(atual)

        if atual == meta:
            return caminho

        for mov in MOVIMENTOS:
            ni, nj = atual[0] + mov[0], atual[1] + mov[1]

            if 0 <= ni < len(labirinto) and 0 <= nj < len(labirinto[0]):
                vizinho = labirinto[ni][nj]
                custo = CUSTO[vizinho]

                if custo < float('inf'):
                    nova_pos = (ni, nj)
                    novo_g = g + custo
                    novo_f = novo_g + heuristica(nova_pos, meta)
                    heapq.heappush(fila, (novo_f, novo_g, nova_pos, caminho + [nova_pos]))

    return None  # Caminho não encontrado

# Executar o algoritmo
caminho = a_estrela(labirinto)

# Exibir o resultado
if caminho:
    print("Caminho encontrado:")
    for passo in caminho:
        print(passo)
else:
    print("Nenhum caminho encontrado.")
