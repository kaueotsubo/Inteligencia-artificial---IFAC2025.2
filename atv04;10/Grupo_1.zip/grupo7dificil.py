import heapq

# Novo labirinto 8x10 com inimigos e armadilhas
labirinto = [
    [0,  0, 1, 0, 2, 0, 0, 0, 'E', 0],
    [1,  1, 1, 0, 1, 0, 3, 0, 1,   0],
    [0,  0, 0, 0, 0, 0, 1, 0, 2,   0],
    [0, 'E',1, 1, 1, 0, 0, 0, 0,   0],
    ['S', 0, 0, 0, 1, 0, 'E',1, 1, 0],
    [0, 1, 3, 0, 1, 0, 0, 0, 0,   0],
    [0, 1, 0, 0, 0, 0, 1, 1, 1,   1],
    [0, 0, 0, 1, 0, 0, 0, 0, 2,  'G']
]

# Custos base das células
CUSTO_BASE = {
    0: 1,   # Caminho livre
    1: float('inf'),  # Parede
    2: 5,   # Armadilha (dano)
    3: 2,   # Armadilha (paralisa: custo 1 + 1 turno perdido)
    'S': 1,
    'G': 1,
    'E': float('inf')  # Não pode pisar em inimigo
}

# Direções para mover: cima, baixo, esquerda, direita
MOVIMENTOS = [(-1, 0), (1, 0), (0, -1), (0, 1)]

# Direções ao redor (8 direções) para checar área de risco de inimigo
DIRECOES_AO_REDEDOR = [(-1, -1), (-1, 0), (-1, 1),
                       (0, -1),          (0, 1),
                       (1, -1),  (1, 0), (1, 1)]

# Encontrar posição de início ('S') e meta ('G')
def encontrar_inicio_meta(lab):
    for i in range(len(lab)):
        for j in range(len(lab[0])):
            if lab[i][j] == 'S':
                inicio = (i, j)
            elif lab[i][j] == 'G':
                meta = (i, j)
    return inicio, meta

# Heurística: distância de Manhattan
def heuristica(pos, meta):
    return abs(pos[0] - meta[0]) + abs(pos[1] - meta[1])

# Verifica se uma posição está na área de dano de um inimigo
def em_area_inimiga(lab, i, j):
    for dx, dy in DIRECOES_AO_REDEDOR + [(0, 0)]:
        ni, nj = i + dx, j + dy
        if 0 <= ni < len(lab) and 0 <= nj < len(lab[0]):
            if lab[ni][nj] == 'E':
                return True
    return False

# Algoritmo A* modificado
def a_estrela_avancado(lab):
    inicio, meta = encontrar_inicio_meta(lab)
    fila = []
    heapq.heappush(fila, (heuristica(inicio, meta), 0, inicio, [inicio]))  # (f, g, pos, caminho)
    visitados = set()

    while fila:
        f, g, atual, caminho = heapq.heappop(fila)

        if atual in visitados:
            continue
        visitados.add(atual)

        if atual == meta:
            return caminho

        for mov in MOVIMENTOS:
            ni, nj = atual[0] + mov[0], atual[1] + mov[1]

            if 0 <= ni < len(lab) and 0 <= nj < len(lab[0]):
                celula = lab[ni][nj]
                if celula == 1 or celula == 'E':
                    continue  # Não pode passar

                custo = CUSTO_BASE[celula]

                # Penalidade por estar na área de risco de um inimigo
                if em_area_inimiga(lab, ni, nj):
                    custo += 10

                nova_pos = (ni, nj)
                novo_g = g + custo
                novo_f = novo_g + heuristica(nova_pos, meta)

                heapq.heappush(fila, (novo_f, novo_g, nova_pos, caminho + [nova_pos]))

    return None  # Caminho não encontrado

# Executar e imprimir resultado
caminho = a_estrela_avancado(labirinto)

if caminho:
    print("Caminho encontrado:")
    for passo in caminho:
        print(passo)
else:
    print("Nenhum caminho possível.")
