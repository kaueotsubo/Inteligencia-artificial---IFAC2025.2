import heapq
import math

# Definindo cada rota como um dicionário com seus custos
rotas = [
    {
        "nome": "S1 - Escada lateral",
        "acesso": 2,
        "detecao": 5,
        "assassino_chance": 2,
        "risco_pior_caso": 5
    },
    {
        "nome": "S2 - Corredor principal",
        "acesso": 1,
        "detecao": 4,
        "assassino_chance": 1,
        "risco_pior_caso": 5
    },
    {
        "nome": "S3 - Duto de ventilação",
        "acesso": 4,
        "detecao": 1,
        "assassino_chance": 5,
        "risco_pior_caso": 3
    },
    {
        "nome": "S4 - Elevador de serviço",
        "acesso": 1,
        "detecao": 1,
        "assassino_chance": 3,
        "risco_pior_caso": 2
    }
]

# Heurística: custo estimado da fuga (quanto menor, melhor)
def calcular_heuristica(rota):
    # Pesos ajustáveis: priorizamos acesso e detecção
    return 0.4 * rota["acesso"] + 0.4 * rota["detecao"] + 0.2 * rota["assassino_chance"]

# Minimax: Minimizado (fugitivo) vs Maximizador (assassino)
# Aqui simplificação: o assassino tenta te alcançar na rota mais provável (mais direto)
def avaliar_minimax(rota):
    # O minimizador (fugitivo) quer te pegar onde há maior chance
    # O maximizador (assassino) quer minimizar o risco no pior cenário
    return max(rota["risco_pior_caso"], rota["assassino_chance"])

# Gera fila de prioridade com base na heurística
fila_heuristica = []
for rota in rotas:
    h = calcular_heuristica(rota)
    heapq.heappush(fila_heuristica, (h, rota))

# Escolha heurística: menor custo estimado
melhor_heuristica = heapq.heappop(fila_heuristica)[1]

# Escolha minimax: menor risco considerando o pior cenário (decisão mais conservadora)
melhor_minimax = min(rotas, key=lambda r: avaliar_minimax(r))

# Mostra resultados
print(">> Melhor escolha heurística:", melhor_heuristica["nome"])
print(">> Melhor escolha minimax:", melhor_minimax["nome"])

# Decisão final baseada na divergência
if melhor_heuristica["nome"] == melhor_minimax["nome"]:
    print("\n✅ Ambas estratégias concordam. Rota escolhida:", melhor_heuristica["nome"])
else:
    # Critério: vamos dar preferência ao minimax em caso de divergência (mais seguro)
    print("\n⚠️ Divergência detectada nas preferências. Escolhendo pela segurança (minimax).")
    print(">> Rota escolhida:", melhor_minimax["nome"])
