import heapq
import random
import itertools

# Constantes
ALERTA_NIVEIS = ["CALMO", "INVESTIGANDO", "ALERTA_MAXIMO"]
PROX_NIVEIS = ["DISTANTE", "PROXIMO", "IMINENTE"]

# Ações disponíveis
ACTIONS = {
    "S1": {"dest": "ESCADA", "turns": 2, "noise": 7, "needs_card": True},
    "S2": {"dest": "CORREDOR", "turns": 3, "noise": 0},
    "S3": {"dest": "DUTO", "turns": 4, "noise": 3},
    "S4": {"dest": "ELEVADOR", "turns": 1, "noise": 0},  # + delay aleatório
}

# Heurística simples (turnos mínimos estimados até saída)
def heuristic(state):
    location = state["location"]
    if location == "SAIDA":
        return 0
    elif location == "DUTO":
        return 4  # Tempo restante no duto
    elif location == "ESCADA" and state["has_card"]:
        return 1
    else:
        return 5  # estimativa conservadora

# Define o novo nível de alerta com base no ruído
def alerta_por_ruido(ruido):
    if ruido <= 5:
        return "CALMO"
    elif ruido <= 10:
        return "INVESTIGANDO"
    else:
        return "ALERTA_MAXIMO"

# Calcula a nova proximidade com base nos turnos
def atualizar_proximidade(turnos):
    index = min(turnos // 5, 2)
    return PROX_NIVEIS[index]

# Estrutura de estado
def estado_inicial():
    return {
        "location": "SAGUAO",
        "turns": 0,
        "noise": 0,
        "alerta": "CALMO",
        "proximidade": "DISTANTE",
        "has_card": False,
        "in_duto": False,
        "history": [],
    }

# Função principal de busca
def busca():
    inicio = estado_inicial()
    heap = []
    counter = itertools.count()
    
    heapq.heappush(heap, (heuristic(inicio), next(counter), inicio))

    visitados = set()

    while heap:
        _, _, atual = heapq.heappop(heap)

        # Se já escapou
        if atual["location"] == "SAIDA":
            print("\n Caminho encontrado:")
            for passo in atual["history"]:
                print("-", passo)
            print("Turnos:", atual["turns"])
            return atual["history"]

        # Evita loops
        chave = (atual["location"], atual["turns"], atual["has_card"], atual["in_duto"], atual["noise"])
        if chave in visitados:
            continue
        visitados.add(chave)

        # Gera ações possíveis
        possiveis = gerar_proximos_estados(atual)
        for prox in possiveis:
            custo_total = prox["turns"] + heuristic(prox)
            heapq.heappush(heap, (custo_total, next(counter), prox))

# Geração de próximos estados com base nas regras
def gerar_proximos_estados(atual):
    novos = []

    loc = atual["location"]

    if loc == "SAGUAO":
        # S1 - Escada (se tiver cartão)
        if atual["has_card"]:
            s1 = avancar(atual, "S1")
            s1["location"] = "SAIDA"
            novos.append(s1)
        # S2 - Corredor
        s2 = avancar(atual, "S2")
        # 50% chance de subir alerta
        if random.random() < 0.5:
            s2["alerta"] = "INVESTIGANDO"
        novos.append(s2)
        # S3 - Duto
        s3 = avancar(atual, "S3")
        s3["location"] = "DUTO"
        s3["in_duto"] = True
        novos.append(s3)
        # S4 - Elevador
        s4 = avancar(atual, "S4")
        if random.random() < 0.7:
            s4["turns"] += 1
        else:
            s4["turns"] += 6
            s4["proximidade"] = "IMINENTE"  # Perigo!
        s4["location"] = "SAIDA"
        novos.append(s4)

    elif loc == "CORREDOR":
        # Ir para sala do gerente
        g = atual.copy()
        g["location"] = "SALA_GERENTE"
        g["turns"] += 2
        g["has_card"] = True
        g["noise"] += 1
        g["alerta"] = alerta_por_ruido(g["noise"])
        g["proximidade"] = atualizar_proximidade(g["turns"])
        g["history"] = atual["history"] + ["Ir para Sala do Gerente e pegar cartão"]
        novos.append(g)

    elif loc == "DUTO":
        if atual["in_duto"]:
            d = atual.copy()
            d["turns"] += 4
            d["location"] = "SAIDA"
            d["history"] = atual["history"] + ["Rastejar pelo duto até a saída"]
            novos.append(d)

    return novos

# Avança o estado de forma genérica
def avancar(atual, acao):
    nova = atual.copy()
    a = ACTIONS[acao]
    nova["turns"] += a["turns"]
    nova["noise"] += a["noise"]
    nova["alerta"] = alerta_por_ruido(nova["noise"])
    nova["proximidade"] = atualizar_proximidade(nova["turns"])
    nova["history"] = atual["history"] + [f"Executar ação {acao} -> {a['dest']}"]
    return nova

# Rodar o algoritmo
if __name__ == "__main__":
    busca()
