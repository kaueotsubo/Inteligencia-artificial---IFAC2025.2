import math
import copy

# Inicializa o tabuleiro 5x5 vazio
def criar_tabuleiro():
    return [[" " for _ in range(5)] for _ in range(5)]

# Imprime o tabuleiro
def imprimir_tabuleiro(tab):
    print("  1 2 3 4 5")
    for i, linha in enumerate(tab):
        print(chr(65+i), " ".join(linha))
    print()

# Converte jogada do tipo 'A1' para índices
def jogada_para_indices(jogada):
    linha = ord(jogada[0].upper()) - 65
    coluna = int(jogada[1]) - 1
    return linha, coluna

# Verifica se uma jogada está dentro do tabuleiro
def jogada_valida(tab, linha, coluna, ultima_jogada):
    if linha < 0 or linha > 4 or coluna < 0 or coluna > 4:
        return False
    if tab[linha][coluna] != " ":
        return False
    # Restrição de casa adjacente à última jogada do mesmo jogador
    if ultima_jogada:
        lin_ant, col_ant = ultima_jogada
        if abs(linha - lin_ant) <= 1 and abs(coluna - col_ant) <= 1:
            return False
    return True

# Verifica se o jogador venceu
def verificar_vitoria(tab, jogador):
    # Checa horizontal, vertical e diagonais
    for i in range(5):
        for j in range(3):
            if all(tab[i][j+k] == jogador for k in range(3)):
                return True
            if all(tab[j+k][i] == jogador for k in range(3)):
                return True
    # Diagonais
    for i in range(3):
        for j in range(3):
            if all(tab[i+k][j+k] == jogador for k in range(3)):
                return True
            if all(tab[i+2-k][j+k] == jogador for k in range(3)):
                return True
    return False

# Verifica empate
def verificar_empate(tab):
    return all(tab[i][j] != " " for i in range(5) for j in range(5))

# Retorna lista de jogadas válidas considerando restrição
def jogadas_validas(tab, ultima_jogada):
    jogadas = []
    for i in range(5):
        for j in range(5):
            if jogada_valida(tab, i, j, ultima_jogada):
                jogadas.append((i, j))
    return jogadas

# Função de avaliação simples
def avaliar(tab):
    if verificar_vitoria(tab, "O"):
        return 10
    elif verificar_vitoria(tab, "X"):
        return -10
    else:
        return 0

# Minimax com poda alfa-beta
def minimax(tab, profundidade, alpha, beta, maximizando, ultima_jogada_X, ultima_jogada_O):
    score = avaliar(tab)
    if score == 10 or score == -10 or profundidade == 0 or verificar_empate(tab):
        return score

    if maximizando:
        max_eval = -math.inf
        for i, j in jogadas_validas(tab, ultima_jogada_O):
            tab[i][j] = "O"
            eval = minimax(tab, profundidade-1, alpha, beta, False, ultima_jogada_X, (i,j))
            tab[i][j] = " "
            max_eval = max(max_eval, eval)
            alpha = max(alpha, eval)
            if beta <= alpha:
                break
        return max_eval
    else:
        min_eval = math.inf
        for i, j in jogadas_validas(tab, ultima_jogada_X):
            tab[i][j] = "X"
            eval = minimax(tab, profundidade-1, alpha, beta, True, (i,j), ultima_jogada_O)
            tab[i][j] = " "
            min_eval = min(min_eval, eval)
            beta = min(beta, eval)
            if beta <= alpha:
                break
        return min_eval

# Computador escolhe a melhor jogada
def melhor_jogada(tab, ultima_jogada_X, ultima_jogada_O):
    melhor_valor = -math.inf
    melhor_mov = None
    for i, j in jogadas_validas(tab, ultima_jogada_O):
        tab[i][j] = "O"
        valor = minimax(tab, 3, -math.inf, math.inf, False, ultima_jogada_X, (i,j))
        tab[i][j] = " "
        if valor > melhor_valor:
            melhor_valor = valor
            melhor_mov = (i, j)
    return melhor_mov

# Função principal do jogo
def jogar():
    tab = criar_tabuleiro()
    ultima_jogada_X = None
    ultima_jogada_O = None
    imprimir_tabuleiro(tab)

    while True:
        # Jogada do humano
        while True:
            jogada = input("Digite sua jogada (ex: A1): ")
            try:
                linha, coluna = jogada_para_indices(jogada)
                if jogada_valida(tab, linha, coluna, ultima_jogada_X):
                    tab[linha][coluna] = "X"
                    ultima_jogada_X = (linha, coluna)
                    break
                else:
                    print("Jogada inválida. Tente novamente.")
            except:
                print("Formato inválido. Use A1, B3, etc.")

        imprimir_tabuleiro(tab)

        if verificar_vitoria(tab, "X"):
            print("Parabéns! Você venceu!")
            break
        if verificar_empate(tab):
            print("Empate!")
            break

        # Jogada do computador
        mov = melhor_jogada(tab, ultima_jogada_X, ultima_jogada_O)
        if mov:
            linha, coluna = mov
            tab[linha][coluna] = "O"
            ultima_jogada_O = (linha, coluna)
            print(f"Computador jogou em {chr(65+linha)}{coluna+1}")
        else:
            print("Empate!")
            break

        imprimir_tabuleiro(tab)

        if verificar_vitoria(tab, "O"):
            print("Computador venceu!")
            break
        if verificar_empate(tab):
            print("Empate!")
            break

# Inicia o jogo
if __name__ == "__main__":
    jogar()
