# Mini Xadrez 4x4 Interativo - Usuário vs Computador (Minimax)
import math

# Estado inicial do tabuleiro vazio
tabuleiro = [['' for _ in range(4)] for _ in range(4)]

JOGADOR_HUMANO = 'X'
JOGADOR_COMPUTADOR = 'O'

def imprimir_tabuleiro(tab):
    print("  1  2  3  4")
    for i, linha in enumerate(tab):
        print(chr(65+i), end=' ')
        for celula in linha:
            print(celula if celula != '' else '.', end='  ')
        print()
    print()

def verificar_vitoria(tab):
    for i in range(4):
        for j in range(2):  # linhas e colunas de 3
            # Linhas
            if tab[i][j] != '' and tab[i][j] == tab[i][j+1] == tab[i][j+2]:
                return tab[i][j]
            # Colunas
            if tab[j][i] != '' and tab[j][i] == tab[j+1][i] == tab[j+2][i]:
                return tab[j][i]
    diagonais = [
        [(0,0),(1,1),(2,2)], [(0,1),(1,2),(2,3)], [(1,0),(2,1),(3,2)], [(1,1),(2,2),(3,3)],
        [(0,2),(1,1),(2,0)], [(0,3),(1,2),(2,1)], [(1,3),(2,2),(3,1)], [(1,2),(2,1),(3,0)]
    ]
    for d in diagonais:
        a,b,c = d
        if tab[a[0]][a[1]] != '' and tab[a[0]][a[1]] == tab[b[0]][b[1]] == tab[c[0]][c[1]]:
            return tab[a[0]][a[1]]
    return None

def cheio(tab):
    for linha in tab:
        if '' in linha:
            return False
    return True

def avaliar(tab):
    vencedor = verificar_vitoria(tab)
    if vencedor == JOGADOR_COMPUTADOR:
        return 10
    elif vencedor == JOGADOR_HUMANO:
        return -10
    else:
        return 0

def minimax(tab, profundidade, maximizando, alfa, beta):
    pontuacao = avaliar(tab)
    if pontuacao != 0 or cheio(tab) or profundidade == 0:
        return pontuacao

    if maximizando:
        max_val = -math.inf
        for i in range(4):
            for j in range(4):
                if tab[i][j] == '':
                    tab[i][j] = JOGADOR_COMPUTADOR
                    valor = minimax(tab, profundidade-1, False, alfa, beta)
                    tab[i][j] = ''
                    max_val = max(max_val, valor)
                    alfa = max(alfa, valor)
                    if beta <= alfa:
                        return max_val
        return max_val
    else:
        min_val = math.inf
        for i in range(4):
            for j in range(4):
                if tab[i][j] == '':
                    tab[i][j] = JOGADOR_HUMANO
                    valor = minimax(tab, profundidade-1, True, alfa, beta)
                    tab[i][j] = ''
                    min_val = min(min_val, valor)
                    beta = min(beta, valor)
                    if beta <= alfa:
                        return min_val
        return min_val

def jogada_computador(tab):
    melhor_valor = -math.inf
    jogada = (-1,-1)
    for i in range(4):
        for j in range(4):
            if tab[i][j] == '':
                tab[i][j] = JOGADOR_COMPUTADOR
                valor = minimax(tab, profundidade=3, maximizando=False, alfa=-math.inf, beta=math.inf)
                tab[i][j] = ''
                if valor > melhor_valor:
                    melhor_valor = valor
                    jogada = (i,j)
    tab[jogada[0]][jogada[1]] = JOGADOR_COMPUTADOR
    print(f"Computador jogou em {chr(65+jogada[0])}{jogada[1]+1}")

def jogada_humana(tab):
    while True:
        try:
            move = input("Digite sua jogada (ex: A1, B3): ").upper()
            if len(move) != 2:
                raise ValueError
            linha = ord(move[0]) - 65
            coluna = int(move[1]) - 1
            if linha < 0 or linha > 3 or coluna < 0 or coluna > 3:
                raise ValueError
            if tab[linha][coluna] != '':
                print("Celula ocupada! Tente outra.")
                continue
            tab[linha][coluna] = JOGADOR_HUMANO
            break
        except ValueError:
            print("Entrada inválida! Use formato A1, B2, etc.")

# Loop do jogo
print("Bem-vindo ao Mini Xadrez 4x4!")
imprimir_tabuleiro(tabuleiro)

while True:
    # Jogada do humano
    jogada_humana(tabuleiro)
    imprimir_tabuleiro(tabuleiro)
    if verificar_vitoria(tabuleiro) == JOGADOR_HUMANO:
        print("Parabéns! Você venceu!")
        break
    if cheio(tabuleiro):
        print("Empate!")
        break

    # Jogada do computador
    jogada_computador(tabuleiro)
    imprimir_tabuleiro(tabuleiro)
    if verificar_vitoria(tabuleiro) == JOGADOR_COMPUTADOR:
        print("Computador venceu!")
        break
    if cheio(tabuleiro):
        print("Empate!")
        break
