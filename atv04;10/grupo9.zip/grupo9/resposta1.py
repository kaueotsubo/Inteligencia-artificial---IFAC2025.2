import time

def resolver_com_busca_heuristica():
    """
    Aplica a lógica de um algoritmo de busca heurística (Busca Gulosa)
    para resolver o desafio "A Grande Fuga".
    """
    
    # 1. DEFINIÇÃO DO PROBLEMA E DOS DADOS
    # Cada rota é um 'nó' adjacente que podemos escolher.
    # As pontuações são os atributos de cada nó.
    rotas = {
        'S1 - Escada Lateral': {'furtividade': 1, 'acesso': 8, 'confiabilidade': 10},
        'S2 - Corredor Principal': {'furtividade': 1, 'acesso': 9, 'confiabilidade': 10},
        'S3 - Duto de Ventilação': {'furtividade': 9, 'acesso': 2, 'confiabilidade': 7},
        'S4 - Elevador de Serviço': {'furtividade': 10, 'acesso': 10, 'confiabilidade': 3}
    }
    
    # 2. DEFINIÇÃO DA FUNÇÃO HEURÍSTICA h(n)
    # Os pesos definem nossa estratégia: priorizar furtividade e acesso rápido.
    pesos = {
        'furtividade': 6,
        'acesso': 3,
        'confiabilidade': 1
    }
    
    print("--- INICIANDO ALGORITMO DE BUSCA HEURÍSTICA ---")
    print("Objetivo: Encontrar a rota com a maior pontuação heurística (h(n)).\n")
    print(f"Fórmula Heurística: h(n) = (P_Furtividade * F) + (P_Acesso * A) + (P_Confiabilidade * C)")
    print(f"Pesos definidos: Furtividade={pesos['furtividade']}, Acesso Rápido={pesos['acesso']}, Confiabilidade={pesos['confiabilidade']}\n")
    time.sleep(2)

    melhor_rota = None
    max_pontuacao = -1

    # 3. APLICAÇÃO DA BUSCA GULOSA
    # O algoritmo avalia cada opção disponível a partir do estado atual.
    for nome_rota, scores in rotas.items():
        
        h_furtividade = pesos['furtividade'] * scores['furtividade']
        h_acesso = pesos['acesso'] * scores['acesso']
        h_confiabilidade = pesos['confiabilidade'] * scores['confiabilidade']
        
        pontuacao_total = h_furtividade + h_acesso + h_confiabilidade
        
        print(f"Avaliando nó '{nome_rota}':")
        print(f"  h(n) = ({pesos['furtividade']}*{scores['furtividade']}) + ({pesos['acesso']}*{scores['acesso']}) + ({pesos['confiabilidade']}*{scores['confiabilidade']}) = {pontuacao_total}")
        
        if pontuacao_total > max_pontuacao:
            max_pontuacao = pontuacao_total
            melhor_rota = nome_rota
        
        time.sleep(2)

    # 4. RESULTADO DA BUSCA
    # O algoritmo escolhe o nó que parece mais promissor (maior pontuação).
    print("\n--- RESULTADO DA BUSCA ---")
    print(f"A busca gulosa selecionou a rota que maximiza a função heurística.")
    print(f"A melhor rota é a '{melhor_rota}' com uma pontuação de {max_pontuacao}.")
    print("\nJustificativa: Esta rota oferece a melhor combinação de desaparecimento rápido e confusão para o inimigo, de acordo com a estratégia definida pelos pesos da heurística.")

# Execução do programa
if __name__ == "__main__":
    resolver_com_busca_heuristica()