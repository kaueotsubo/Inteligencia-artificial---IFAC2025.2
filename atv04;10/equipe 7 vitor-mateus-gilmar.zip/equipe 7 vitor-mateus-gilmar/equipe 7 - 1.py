'''
Você foi contratado para desenvolver uma inteligência artificial de navegação autônoma capaz de encontrar a melhor rota em um labirinto cheio de obstáculos e armadilhas.
O ambiente é representado por uma matriz (grid), onde cada célula pode conter:

Símbolo	Descrição
0	Caminho livre
1	Parede (bloqueio)
2	Armadilha (zona perigosa — pode passar, mas tem custo alto)
S	Ponto de início
G	Ponto de chegada (objetivo)
🧠 Desafio proposto

Você deverá implementar e comparar dois tipos de busca para encontrar um caminho do ponto S (início) até o ponto G (meta):

Busca Cega (BFS – Breadth-First Search)

Explora todos os caminhos possíveis sem levar em conta o custo ou perigo.

Deve retornar o primeiro caminho encontrado até a meta, mesmo que ele passe por armadilhas.

Busca Heurística (A*)

Considera o custo real percorrido (g) e uma estimativa da distância restante (h).

Cada armadilha (2) deve ter um peso maior (ex: +3 no custo).

Deve tentar encontrar o caminho mais seguro e eficiente, evitando zonas de alto risco.

⚙ Requisitos da Implementação

O labirinto deve ser representado como uma matriz bidimensional em Python.

Ambas as buscas devem exibir:

O caminho encontrado.

O custo total do percurso.

O número de passos até o objetivo.

Ao final, exiba uma comparação entre os dois métodos, destacando:

Qual chegou primeiro.

Qual foi mais seguro.

Qual teve o menor custo total.

🧩 Exemplo de mapa:
labirinto = [
    [0, 2, 0, 0, 1, 0],
    [0, 1, 1, 0, 2, 0],
    ['S', 0, 0, 2, 0, 'G'],
    [0, 1, 0, 0, 0, 0]
]

🧭 Critérios de Avaliação
Critério	Descrição	Pontos
Implementação correta do BFS	Encontra caminho básico até a meta	2 pts
Implementação correta do A*	Considera heurística e risco	3 pts
Exibição e comparação dos resultados	Mostra caminho, custo e análise final	3 pts
Clareza e organização do código	Boa estrutura, comentários e nomes claros	2 pts
💡 Desafio bônus (opcional)

Adicione elementos dinâmicos:

Áreas de neblina (descobertas apenas quando o agente se aproxima).

Células que mudam de valor com o tempo (por exemplo, uma armadilha que vira parede).

Isso fará com que até uma IA avançada precise se adaptar e “repensar” a rota.



'''

import collections
import heapq

# 🧩 Exemplo de mapa fornecido no desafio
labirinto = [
    [0, 2, 0, 0, 1, 0],
    [0, 1, 1, 0, 2, 0],
    ['S', 0, 0, 2, 0, 'G'],
    [0, 1, 0, 0, 0, 0]
]

def encontrar_posicao(labirinto, simbolo):
    """Encontra a posição (linha, coluna) de um símbolo no labirinto."""
    for i, linha in enumerate(labirinto):
        for j, celula in enumerate(linha):
            if celula == simbolo:
                return (i, j)
    return None

def obter_vizinhos(labirinto, pos):
    """Retorna uma lista de vizinhos válidos (não são paredes e estão dentro do grid)."""
    vizinhos = []
    linha, col = pos
    movimentos = [(0, 1), (0, -1), (1, 0), (-1, 0)]  # Direita, Esquerda, Baixo, Cima

    for dr, dc in movimentos:
        nova_linha, nova_col = linha + dr, col + dc
        
        # Verifica se está dentro dos limites do labirinto
        if 0 <= nova_linha < len(labirinto) and 0 <= nova_col < len(labirinto[0]):
            # Verifica se não é uma parede
            if labirinto[nova_linha][nova_col] != 1:
                vizinhos.append((nova_linha, nova_col))
    return vizinhos

def reconstruir_caminho(pais, inicio, fim):
    """Reconstrói o caminho do fim para o início usando o dicionário de pais."""
    caminho = []
    atual = fim
    while atual is not None:
        caminho.append(atual)
        atual = pais.get(atual)
    return caminho[::-1] # Retorna o caminho do início para o fim

def calcular_custo_caminho(labirinto, caminho):
    """Calcula o custo total de um caminho, considerando as armadilhas."""
    custo = 0
    # O custo é contado a partir do primeiro passo, não da posição inicial
    for pos in caminho[1:]:
        linha, col = pos
        celula = labirinto[linha][col]
        if celula == 2:
            custo += 4 # Custo do passo (1) + penalidade da armadilha (3)
        else:
            custo += 1 # Custo normal do passo
    return custo

# ==============================================================================
# 1. Implementação da Busca Cega (BFS)
# ==============================================================================
def busca_bfs(labirinto, inicio, fim):
    """
    Executa a busca em largura (BFS) para encontrar o caminho mais curto em número de passos.
    """
    fila = collections.deque([inicio])
    visitados = {inicio}
    pais = {inicio: None}
    
    while fila:
        atual = fila.popleft()
        
        if atual == fim:
            caminho = reconstruir_caminho(pais, inicio, fim)
            custo = calcular_custo_caminho(labirinto, caminho)
            passos = len(caminho) - 1
            return caminho, custo, passos
            
        for vizinho in obter_vizinhos(labirinto, atual):
            if vizinho not in visitados:
                visitados.add(vizinho)
                pais[vizinho] = atual
                fila.append(vizinho)
                
    return None, 0, 0 # Caminho não encontrado

# ==============================================================================
# 2. Implementação da Busca Heurística (A*)
# ==============================================================================
def heuristica_manhattan(a, b):
    """Calcula a distância de Manhattan entre dois pontos."""
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

def busca_a_estrela(labirinto, inicio, fim):
    """
    Executa a busca A* para encontrar o caminho de menor custo, considerando armadilhas.
    """
    # Fila de prioridade armazena tuplas: (f_score, g_score, posicao)
    fila_prio = [(heuristica_manhattan(inicio, fim), 0, inicio)] 
    
    # Dicionários para armazenar custos e o caminho
    g_scores = {inicio: 0}
    pais = {inicio: None}

    while fila_prio:
        # Pega o nó com o menor f_score
        f_score, g_score, atual = heapq.heappop(fila_prio)

        if atual == fim:
            caminho = reconstruir_caminho(pais, inicio, fim)
            custo = g_score # O custo final já é o g_score do objetivo
            passos = len(caminho) - 1
            return caminho, custo, passos

        for vizinho in obter_vizinhos(labirinto, atual):
            valor_celula = labirinto[vizinho[0]][vizinho[1]]
            
            custo_passo = 4 if valor_celula == 2 else 1
            
            novo_g_score = g_score + custo_passo

            if vizinho not in g_scores or novo_g_score < g_scores[vizinho]:
                g_scores[vizinho] = novo_g_score
                h_score = heuristica_manhattan(vizinho, fim)
                f_score_vizinho = novo_g_score + h_score
                heapq.heappush(fila_prio, (f_score_vizinho, novo_g_score, vizinho))
                pais[vizinho] = vizinho # Correção: o pai do vizinho é o 'atual'
                pais[vizinho] = atual


    return None, 0, 0 # Caminho não encontrado

# ==============================================================================
# 3. Exibição e Comparação dos Resultados
# ==============================================================================
def exibir_resultados(nome_busca, resultado):
    caminho, custo, passos = resultado
    print(f"--- Resultados para: {nome_busca} ---")
    if caminho:
        print(f"Caminho encontrado: {caminho}")
        print(f"Custo total do percurso: {custo}")
        print(f"Número de passos: {passos}\n")
    else:
        print("Nenhum caminho foi encontrado.\n")

if _name_ == "_main_":
    ponto_inicio = encontrar_posicao(labirinto, 'S')
    ponto_fim = encontrar_posicao(labirinto, 'G')

    if not ponto_inicio or not ponto_fim:
        print("Erro: Ponto de início 'S' ou de chegada 'G' não encontrado no labirinto.")
    else:
        print(f"Iniciando busca de {ponto_inicio} para {ponto_fim}\n")

        # Executa as buscas
        resultado_bfs = busca_bfs(labirinto, ponto_inicio, ponto_fim)
        resultado_a_estrela = busca_a_estrela(labirinto, ponto_inicio, ponto_fim)

        # Exibe os resultados individuais
        exibir_resultados("Busca Cega (BFS)", resultado_bfs)
        exibir_resultados("Busca Heurística (A*)", resultado_a_estrela)
        
        # Comparação final
        caminho_bfs, custo_bfs, passos_bfs = resultado_bfs
        caminho_a, custo_a, passos_a = resultado_a_estrela

        print("="*40)
        print("📊 COMPARAÇÃO FINAL 📊")
        print("="*40)

        # 1. Qual chegou primeiro (em termos de passos)
        if passos_bfs < passos_a:
            print(f"🥇 Mais Rápido (em passos): BFS chegou em {passos_bfs} passos.")
        elif passos_a < passos_bfs:
            print(f"🥇 Mais Rápido (em passos): A* chegou em {passos_a} passos.")
        else:
            print(f"🏁 Empate em Rapidez: Ambos levaram {passos_bfs} passos.")
        
        # 2. Qual foi mais seguro (evitou armadilhas)
        armadilhas_bfs = sum(1 for pos in caminho_bfs if labirinto[pos[0]][pos[1]] == 2)
        armadilhas_a = sum(1 for pos in caminho_a if labirinto[pos[0]][pos[1]] == 2)

        if armadilhas_a < armadilhas_bfs:
            print(f"🛡 Mais Seguro: A* encontrou um caminho com menos armadilhas ({armadilhas_a}) do que o BFS ({armadilhas_bfs}).")
        elif armadilhas_bfs < armadilhas_a:
             print(f"🛡 Mais Seguro: BFS encontrou um caminho com menos armadilhas ({armadilhas_bfs}) do que o A* ({armadilhas_a}).")
        else:
            print(f"🛡 Nível de Segurança: Ambos os caminhos passaram por {armadilhas_a} armadilha(s).")
            
        # 3. Qual teve o menor custo total
        if custo_a < custo_bfs:
            print(f"💰 Menor Custo Total: A* venceu com um custo de {custo_a} contra {custo_bfs} do BFS.")
        elif custo_bfs < custo_a:
            print(f"💰 Menor Custo Total: BFS venceu com um custo de {custo_bfs} contra {custo_a} do A*.")
        else:
            print(f"💰 Empate em Custo: Ambos os caminhos tiveram um custo final de {custo_a}.")
        print("="*40)