'''
enunciado equipe 12 
Diferencie a abordagem da Busca Gulosa (Greedy Best-First Search) e da Busca A*(A-

Star) ao resolver o problema de encontrar a rota mais curta em um mapa. Explique o risco

principal da Busca Gulosa (relacionado a sua dependência ifxclusiva da heuristica) e como

a inclusão do custo acumulado (g(n)) na Busca A* mitiga esse risco, garantindo uma

solução ótima (o caminho mais curto, se a heuristica for admissivel).



enunciado equipe 7


Desafio de Navegação em Marte: Greedy vs. A*
Você é o engenheiro-chefe de uma missão de exploração em Marte. Seu rover autônomo, "Perseverança II", precisa navegar de um ponto de partida até uma base de pesquisa, economizando o máximo de energia possível. O terreno marciano é variado e a rota mais curta em distância nem sempre é a mais eficiente em termos de consumo de energia.

O ambiente é representado por uma matriz (grid), onde cada célula pode conter:

Símbolo	Descrição	Custo de Energia para Entrar
0	Planície (terreno plano)	1 ponto
3	Terreno Acidentado (areia fofa, rochas)	5 pontos
1	Montanha (obstáculo intransponível)	-
S	Ponto de partida do rover	1 ponto
G	Base de chegada (objetivo)	1 ponto

Exportar para as Planilhas
🧠 Desafio Proposto

Sua tarefa é implementar e comparar duas IAs de navegação para o rover, cada uma usando um algoritmo de busca diferente para encontrar um caminho de S até G:

Busca Gulosa (Greedy Best-First Search)

Lógica: Esta IA é "apressada". Ela sempre se move para a célula vizinha que parece estar mais perto da base (G), baseando-se unicamente na heurística (distância em linha reta ou Manhattan). Ela ignora o custo de energia do terreno percorrido.

Fórmula: f(n)=h(n)

Busca Heurística (A*)

Lógica: Esta IA é "eficiente". Ela busca o caminho com o menor custo total de energia. Para isso, ela equilibra o custo de energia já gasto para chegar a uma célula (g(n)) com a distância estimada restante até a base (h(n)).

Fórmula: f(n)=g(n)+h(n)

⚙ Requisitos da Implementação

O mapa de Marte deve ser representado como uma matriz bidimensional em Python.

Ambas as buscas devem exibir:

O caminho encontrado como uma lista de coordenadas.

O custo total de energia do percurso (some os custos de cada célula do caminho, exceto o ponto de partida).

O número de passos (comprimento do caminho).

Ao final, exiba uma análise comparativa detalhada, explicando:

Qual algoritmo encontrou o caminho com menor custo de energia e por quê.

Qual algoritmo encontrou o caminho com menos passos.

Explique especificamente por que a Busca Gulosa escolheu seu caminho e como a inclusão do custo acumulado (g(n)) permitiu que o A* tomasse uma decisão "mais inteligente" e evitasse a rota de alto custo.

🧩 Exemplo de Mapa de Marte:

Este mapa foi projetado para ter uma "armadilha" para a Busca Gulosa: um caminho que parece direto, mas é extremamente custoso.

Python

mapa_marte = [
    [1, 'S', 1, 0, 0, 0, 1],
    [1, 3, 1, 0, 1, 0, 1],
    [1, 3, 1, 0, 1, 0, 1],
    [1, 3, 0, 0, 1, 0, 1],
    [1, 'G', 1, 1, 1, 0, 1]
]
'''






'''
solução
'''



import heapq

def ucs_busca_energia(mapa_marte):
    """
    Implementa a Busca de Custo Uniforme (UCS) para encontrar o caminho
    de menor custo (menor consumo de energia) no mapa de Marte.
    UCS é uma forma de busca cega ótima para custo.
    """
    
    # 1. Definições do Mapa e Custos
    CUSTOS = {
        '0': 1,  # Planície
        '3': 5,  # Terreno Acidentado
        'S': 1,  # Ponto de Partida (custo do próximo passo)
        'G': 1   # Objetivo (custo para ENTRAR no objetivo)
    }
    
    LINHAS = len(mapa_marte)
    COLUNAS = len(mapa_marte[0])

    # Encontra as coordenadas de S (Start) e G (Goal)
    start = None
    goal = None
    for r in range(LINHAS):
        for c in range(COLUNAS):
            if mapa_marte[r][c] == 'S':
                start = (r, c)
            elif mapa_marte[r][c] == 'G':
                goal = (r, c)
    
    if not start or not goal:
        return "Erro: 'S' ou 'G' não encontrados no mapa.", None

    # Movimentos possíveis (ortogonais)
    movimentos = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    # 2. Inicialização da Busca de Custo Uniforme (UCS)
    
    # Fila de Prioridade: (g_score, (r, c), caminho_percorrido)
    # g_score é a prioridade
    fila_prioridade = [(0, start, [start])] 
    
    # Armazena o menor custo g_score encontrado para cada nó (otimização)
    g_scores = {start: 0}

    # 3. Loop Principal de Busca
    while fila_prioridade:
        # Pega o nó com o menor CUSTO ACUMULADO (g_score)
        g_score, atual, caminho = heapq.heappop(fila_prioridade)

        # Verifica se o objetivo foi alcançado
        if atual == goal:
            return f"Caminho encontrado (Busca de Custo Uniforme) com custo mínimo de energia: {g_score} pontos.", caminho

        # Explora os vizinhos
        for dr, dc in movimentos:
            vizinho_r, vizinho_c = atual[0] + dr, atual[1] + dc
            vizinho = (vizinho_r, vizinho_c)

            # Verifica limites do mapa
            if not (0 <= vizinho_r < LINHAS and 0 <= vizinho_c < COLUNAS):
                continue

            simbolo = mapa_marte[vizinho_r][vizinho_c]
            
            # Verifica se é Montanha (Obstáculo Intransponível '1')
            if simbolo == '1': 
                 continue 
            
            # Determina o custo de ENTRAR na célula vizinha
            custo_entrada = CUSTOS.get(simbolo, float('inf')) 
            
            # Calcula o novo custo G (custo real acumulado)
            novo_g_score = g_score + custo_entrada
            
            # Se o novo caminho for pior ou igual a um já conhecido, ignora
            if novo_g_score < g_scores.get(vizinho, float('inf')):
                
                # Atualiza o melhor g_score para este nó
                g_scores[vizinho] = novo_g_score
                
                # Cria o novo caminho
                novo_caminho = caminho + [vizinho]
                
                # Adiciona à fila de prioridade (prioridade é o novo_g_score)
                heapq.heappush(fila_prioridade, (novo_g_score, vizinho, novo_caminho))

    # Se a fila esvaziar sem encontrar o objetivo
    return "Não foi possível encontrar um caminho de S a G.", None

# --- Execução com o Mapa Fornecido ---

mapa_marte = [
    [1,'S',1, 0, 0, 0, 1],
    [1, 3, 1, 0, 1, 0, 1],
    [1, 3, 1, 0, 1, 0, 1],
    [1, 3, 0, 0, 1, 0, 1],
    [1,'G', 1, 1, 1, 0, 1]
]

# Garantir que o mapa é de strings para o dict CUSTOS
mapa_str = [[str(item) for item in row] for row in mapa_marte]

resultado, caminho_solucao = ucs_busca_energia(mapa_str)

# --- Impressão dos Resultados ---
print("--- Algoritmo de Busca Cega (Busca de Custo Uniforme) ---")
print(resultado)
if caminho_solucao:
    print("\nDetalhes do Caminho (Linha, Coluna):")
    caminho_formatado = " -> ".join([f"({r},{c})" for r, c in caminho_solucao])
    print(caminho_formatado)
    
    # Verificação do custo total
    custo_total = 0
    custos_passo = []
    
    custos_passo.append("S (0)")
    
    for r, c in caminho_solucao[1:]:
        simbolo = mapa_marte[r][c]
        custo_passo = CUSTOS.get(str(simbolo), 0)
        custo_total += custo_passo
        custos_passo.append(f"{simbolo} ({custo_passo})")

    print(f"\nConsumo de Energia por Célula (do 2º passo ao G):")
    print(" + ".join(custos_passo[1:]))
    print(f"Custo de Energia Verificado: {custo_total} pontos.")