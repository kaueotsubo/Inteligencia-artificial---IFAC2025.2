'''
Você foi contratado para desenvolver...
Você foi contratado para desenvolver uma inteligência artificial de navegação autônoma capaz de encontrar a melhor rota em um labirinto cheio de obstáculos, armadilhas e inimigos. O ambiente é representado por uma (grid), onde cada célula pode conter:

Símbolo

Tipo

Custo / Efeito

'0'

Caminho livre

Custo 1

'1'

Parede

Intransponível

'3'

Armadilha (dano)

Custo 5

'2'

Armadilha (paralisia)

Custo 1, mas paralisa o agente por 1 turno (perde 1 movimento)

'E'

Inimigo

Inimigo perigoso. Causa dano se o agente estiver na célula ou ao redor

'S'

Ponto de Início

Sem custo adicional

'G'

Ponto de Chegada

Sem custo adicional

labirinto = [
[0, 0, 1, 0, 0, 0, 'E', 0, 0],
['S', 1, 0, 1, 0, 3, 0, 1, 0],
[0, 0, 0, 0, 0, 1, 0, 2, 0],
[0, 'E', 1, 1, 1, 0, 0, 0, 0],
[0, 0, 0, 0, 1, 0, 'E', 1, 1],
[0, 1, 3, 0, 1, 0, 0, 0, 0],
[0, 1, 0, 0, 0, 0, 1, 1, 1],
[0, 0, 0, 1, 0, 0, 0, 2, 'G']
]
'''


import heapq
import sys
import io

# Tenta configurar a saída padrão para UTF-8. 
try:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
except:
    pass


# --- 1. Definição do Labirinto e Custos de Energia ---

# Custo de Dano Adicional por Inimigo (para células adjacentes ou a própria célula 'E')
ENEMY_ADJACENCY_DAMAGE = 9

# Novos custos base conforme as regras do problema
BASE_CUSTOS = {
    0: 1,           # Caminho Livre (Custo 1)
    1: float('inf'), # Parede (Intransponível)
    3: 5,           # Armadilha Dano (Custo 5)
    2: 2,           # Armadilha Paralisa (Custo 1 + 1 movimento extra = 2)
    'S': 0,         # Ponto de Início (Sem custo adicional na entrada)
    'G': 0,         # Ponto de Chegada (Sem custo adicional na entrada)
    'E': 10,        # Inimigo (Custo base 1 + dano 9 = 10)
}

# Mapa do Labirinto (8 linhas x 9 colunas - conflito de 'S' em (4, 0) resolvido para 0)
labirinto = [
    [0, 0, 1, 0, 0, 0, 'E', 0, 0], 
    ['S', 1, 0, 1, 0, 3, 0, 1, 0], 
    [0, 0, 0, 0, 0, 1, 0, 2, 0], 
    [0, 'E', 1, 1, 1, 0, 0, 0, 0], 
    [0, 0, 0, 0, 1, 0, 'E', 1, 1], 
    [0, 1, 3, 0, 1, 0, 0, 0, 0], 
    [0, 1, 0, 0, 0, 0, 1, 1, 1], 
    [0, 0, 0, 1, 0, 0, 0, 2, 'G'] 
]

LINHAS = len(labirinto)
COLUNAS = len(labirinto[0])


def pre_calcular_custos_totais(mapa, base_custos):
    """
    Calcula o custo efetivo de entrada em cada célula, 
    incluindo o dano de proximidade do inimigo ('E').
    """
    custos_efetivos = [[0 for _ in range(COLUNAS)] for _ in range(LINHAS)]
    
    # 1. Encontrar posições dos inimigos
    inimigos = []
    for r in range(LINHAS):
        for c in range(COLUNAS):
            if mapa[r][c] == 'E':
                inimigos.append((r, c))

    # Movimentos para checar adjacência (inclui a própria célula para o dano de contato)
    movimentos_adjacentes = [
        (-1, 0), (1, 0), (0, -1), (0, 1), # Vizinhos diretos (Manhattan)
        (0, 0) # A própria célula 'E'
    ]
    
    # 2. Marcar células afetadas por inimigos
    celulas_perigosas = set()
    for er, ec in inimigos:
        for dr, dc in movimentos_adjacentes:
            nr, nc = er + dr, ec + dc
            if 0 <= nr < LINHAS and 0 <= nc < COLUNAS:
                # Se não for uma Parede intransponível, marque como perigosa
                if mapa[nr][nc] != 1:
                    celulas_perigosas.add((nr, nc))

    # 3. Calcular o custo final para cada célula
    for r in range(LINHAS):
        for c in range(COLUNAS):
            simbolo = mapa[r][c]
            base_cost = base_custos.get(simbolo, simbolo) 

            if base_cost == float('inf'):
                final_cost = float('inf')
            elif simbolo == 'E':
                # O custo de 'E' já é 10 (1 base + 9 dano)
                final_cost = base_cost
            elif (r, c) in celulas_perigosas:
                # Células adjacentes a 'E' (que não são 'E')
                # Adiciona o dano de proximidade ao custo base
                final_cost = base_cost + ENEMY_ADJACENCY_DAMAGE
            else:
                # Células seguras
                final_cost = base_cost

            custos_efetivos[r][c] = final_cost
            
    return custos_efetivos

# Geração do mapa de custos efetivos que será usado pelo A*
CUSTOS_EFETIVOS_MAPA = pre_calcular_custos_totais(labirinto, BASE_CUSTOS)

# --- 2. Funções Auxiliares de Busca ---

def encontrar_posicoes(mapa):
    """Encontra as coordenadas (linha, coluna) de 'S' e 'G'."""
    start = None
    goal = None
    for r in range(LINHAS):
        for c in range(COLUNAS):
            if mapa[r][c] == 'S':
                start = (r, c)
            elif mapa[r][c] == 'G':
                goal = (r, c)
    return start, goal

def heuristica_manhattan(atual, objetivo):
    """
    Heurística (h(n)): Custo estimado para ir do ponto atual ao objetivo.
    Usamos Distância de Manhattan, que é admissível (nunca superestima o custo real).
    """
    r1, c1 = atual
    r2, c2 = objetivo
    return abs(r1 - r2) + abs(c1 - c2)

def obter_custo_celula(r, c):
    """Retorna o custo de energia para entrar em uma célula usando o mapa de custos efetivos."""
    return CUSTOS_EFETIVOS_MAPA[r][c] 

# --- 3. O Algoritmo A* (A-Estrela) ---

def busca_a_estrela(mapa):
    """
    Implementa o algoritmo A* para encontrar o caminho de menor custo (energia) 
    entre 'S' (Start) e 'G' (Goal) no labirinto.
    """
    start, goal = encontrar_posicoes(mapa)

    if not start or not goal:
        return "Erro: Pontos de partida ('S') ou chegada ('G') não encontrados.", None

    # Fila de Prioridade (Fronteira): (f_custo, g_custo, linha, coluna)
    # f_custo = g_custo + h_custo (Função de avaliação)
    fronteira = []
    
    # Custo inicial g(S): custo de entrar na célula 'S' (agora 0)
    g_start = obter_custo_celula(start[0], start[1])
    # Heurística inicial h(S)
    h_start = heuristica_manhattan(start, goal)
    # Custo total estimado inicial f(S)
    f_start = g_start + h_start
    heapq.heappush(fronteira, (f_start, g_start, start[0], start[1]))

    # g_custo_energia: custo real (g(n)) para chegar a um nó
    g_custo_energia = {start: g_start}
    # pai: para reconstruir o caminho ideal
    pai = {start: None}

    # Movimentos: (dr, dc) para vizinhos CIMA, BAIXO, ESQUERDA, DIREITA
    movimentos = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    while fronteira:
        # Pega o nó com menor f(n)
        f_atual, g_atual, r_atual, c_atual = heapq.heappop(fronteira)
        no_atual = (r_atual, c_atual)

        # Se chegamos ao objetivo
        if no_atual == goal:
            caminho_otimo = []
            custo_total = g_atual 
            
            # Reconstrução do caminho (de trás para frente)
            while no_atual:
                caminho_otimo.append(no_atual)
                no_atual = pai.get(no_atual)
            
            return custo_total, caminho_otimo[::-1] # Inverte para Start -> Goal

        # Explora vizinhos
        for dr, dc in movimentos:
            r_vizinho, c_vizinho = r_atual + dr, c_atual + dc
            no_vizinho = (r_vizinho, c_vizinho)

            # 1. Verifica se o vizinho está dentro dos limites do mapa
            if 0 <= r_vizinho < LINHAS and 0 <= c_vizinho < COLUNAS:
                
                custo_passo = obter_custo_celula(r_vizinho, c_vizinho)

                # 2. Verifica se é intransponível 
                if custo_passo == float('inf'):
                    continue

                # Custo real (g(n)) para chegar ao vizinho
                novo_g_custo = g_atual + custo_passo
                
                # 3. Verifica se este é um caminho mais curto para o vizinho
                if novo_g_custo < g_custo_energia.get(no_vizinho, float('inf')):
                    
                    # Encontrou um caminho melhor, atualiza os registros
                    pai[no_vizinho] = no_atual
                    g_custo_energia[no_vizinho] = novo_g_custo

                    # Recalcula f(n) para o vizinho
                    h_vizinho = heuristica_manhattan(no_vizinho, goal)
                    f_vizinho = novo_g_custo + h_vizinho
                    
                    # Adiciona/Atualiza o vizinho na fronteira
                    heapq.heappush(fronteira, (f_vizinho, novo_g_custo, r_vizinho, c_vizinho))

    return "Não foi possível encontrar um caminho (Bloqueio total).", None

# --- 4. Execução e Exibição dos Resultados ---

custo_total, caminho = busca_a_estrela(labirinto)

if caminho:
    # Formata o caminho para melhor visualização (e.g., (1, 0) -> (2, 0) -> ...)
    caminho_formatado = " -> ".join([f"({r}, {c})" for r, c in caminho])
    
    # Prepara o mapa com o caminho marcado
    mapa_solucao = [list(row) for row in labirinto]
    for r, c in caminho:
        # Não marca 'S' e 'G' com '*'
        if mapa_solucao[r][c] not in ('S', 'G'):
            mapa_solucao[r][c] = '*' # Marca a célula percorrida
    
    print("----------------------------------------------------------------------")
    print("--- Solução Ótima de Navegação no Labirinto (Algoritmo A*) ---")
    print("----------------------------------------------------------------------")
    print(f"\n✅ Custo Total Mínimo de Energia/Dano: {custo_total} pontos")
    print("\n🗺️ Mapa do Caminho Percorrido:")
    # Converte os elementos para string para o join funcionar corretamente
    for row in mapa_solucao:
        print(" | ".join(map(str, row)))
    
    print(f"\n📍 Rota Ótima (Coordenadas Linha, Coluna):")
    print(caminho_formatado)
else:
    print(custo_total)
