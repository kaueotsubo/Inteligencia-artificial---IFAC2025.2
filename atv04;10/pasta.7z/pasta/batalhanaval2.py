import random

# --- Configurações ---
TAMANHO = 5
NAVIOS = {
    "Porta-aviões": 4,
    "Cruzador": 3,
    "Contratorpedeiro": 2,
    "Rebocador": 1
}
PONTUACAO_NAVIO = {
    "Porta-aviões": 100,
    "Cruzador": 70,
    "Contratorpedeiro": 40,
    "Rebocador": 20
}

# --- Criação do tabuleiro ---
def criar_tabuleiro():
    return [[[0 for _ in range(TAMANHO)] for _ in range(TAMANHO)] for _ in range(TAMANHO)]

# --- Colocar navios aleatoriamente ---
def colocar_navios(tabuleiro):
    for nome, tamanho in NAVIOS.items():
        colocado = False
        while not colocado:
            orientacao = random.choice(["x", "y", "z"])
            x = random.randint(0, TAMANHO - 1)
            y = random.randint(0, TAMANHO - 1)
            z = random.randint(0, TAMANHO - 1)

            # Verifica se o navio cabe no tabuleiro
            if orientacao == "x" and x + tamanho <= TAMANHO:
                coords = [(x+i, y, z) for i in range(tamanho)]
            elif orientacao == "y" and y + tamanho <= TAMANHO:
                coords = [(x, y+i, z) for i in range(tamanho)]
            elif orientacao == "z" and z + tamanho <= TAMANHO:
                coords = [(x, y, z+i) for i in range(tamanho)]
            else:
                continue

            # Verifica sobreposição
            if any(tabuleiro[cx][cy][cz] != 0 for cx, cy, cz in coords):
                continue

            # Coloca o navio
            for cx, cy, cz in coords:
                tabuleiro[cx][cy][cz] = nome[0]  # marca com a inicial do navio
            colocado = True

#Jogo principal
def jogar_batalha_naval():
    print("=== ⚓ BATALHA NAVAL 3D ⚓ ===")
    modo = input("Escolha o nível (normal/dificil): ").strip().lower()
    tiros_disponiveis = 30 if modo == "dificil" else float("inf")

    tabuleiro = criar_tabuleiro()
    colocar_navios(tabuleiro)

    tiros = 0
    acertos = 0
    erros = 0
    navios_destruidos = {nome: 0 for nome in NAVIOS}

    #Loop de jogo
    while tiros < tiros_disponiveis:
        print("\nDigite as coordenadas do tiro (x y z), entre 0 e 4:")
        try:
            x, y, z = map(int, input("> ").split())
        except:
            print("Entrada inválida! Use três números separados por espaço.")
            continue

        if not (0 <= x < TAMANHO and 0 <= y < TAMANHO and 0 <= z < TAMANHO):
            print("Coordenadas fora do limite!")
            continue

        tiros += 1

        if tabuleiro[x][y][z] != 0:
            inicial = tabuleiro[x][y][z]
            # Descobre qual navio foi atingido
            for nome in NAVIOS:
                if nome[0] == inicial:
                    navios_destruidos[nome] += 1
            acertos += 1
            print("🎯 ACERTOU um navio inimigo!")
            tabuleiro[x][y][z] = 0  # marca como destruído
        else:
            erros += 1
            print("🌊 Errou...")

        # Verifica vitória
        if all(tabuleiro[x][y][z] == 0 for x in range(TAMANHO) for y in range(TAMANHO) for z in range(TAMANHO)):
            print("\n💥 Todos os navios foram destruídos! Vitória!")
            break

        if modo == "dificil" and tiros >= tiros_disponiveis:
            print("\n💀 Acabou a munição!")

    # --- Estatísticas ---
    eficiencia = (acertos / tiros) * 100 if tiros > 0 else 0
    pontuacao = sum(PONTUACAO_NAVIO[nome] * navios_destruidos[nome] / NAVIOS[nome] for nome in NAVIOS)

    print("\n=== 📊 ESTATÍSTICAS FINAIS ===")
    print(f"Tiros efetuados: {tiros}")
    print(f"Acertos: {acertos}")
    print(f"Erros: {erros}")
    print(f"Eficiência: {eficiencia:.2f}%")
    print(f"Pontuação total: {pontuacao:.1f}")
    print("\nPontuação por navio:")
    for nome in NAVIOS:
        destruidos = navios_destruidos[nome] / NAVIOS[nome] * 100
        print(f"  {nome}: {destruidos:.0f}% destruído")

#Início do jogo
if __name__ == "__main__":
    jogar_batalha_naval()
