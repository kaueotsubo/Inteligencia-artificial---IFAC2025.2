import math
pontos = {
    "Depósito": (0, 0),
    "A": (1, 5),
    "B": (8, 2),
    "C": (4, 9),
    "D": (7, 6),
    "E": (2, 8)
}

#Função para calcular a distância Euclidiana entre dois pontos
def distancia(p1, p2):
    return math.sqrt((p2[0] - p1[0])**2 + (p2[1] - p1[1])**2)

# Heurística do Vizinho Mais Próximo
def vizinho_mais_proximo(pontos, inicio="Depósito"):
    nao_visitados = pontos.copy()
    rota = [inicio]
    atual = inicio
    del nao_visitados[inicio]
    distancia_total = 0

    while nao_visitados:
        # Encontra o ponto mais próximo do atual
        proximo, dist_min = min(
            ((nome, distancia(pontos[atual], coord)) for nome, coord in nao_visitados.items()),
            key=lambda x: x[1]
        )
        rota.append(proximo)
        distancia_total += dist_min
        atual = proximo
        del nao_visitados[proximo]

    # Retorna ao depósito
    distancia_total += distancia(pontos[atual], pontos[inicio])
    rota.append(inicio)

    return rota, distancia_total

# Executar a heurística
rota, distancia_total = vizinho_mais_proximo(pontos)

# Exibir resultados
print("Rota encontrada:")
print(" -> ".join(rota))
print(f"Distância total: {distancia_total:.2f} unidades")
