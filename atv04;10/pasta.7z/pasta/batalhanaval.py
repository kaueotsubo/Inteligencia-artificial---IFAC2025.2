import random

# Configuração
TAMANHO = 5  # Tabuleiro 5x5x5
NAVIOS = [
    {"tamanho": 4},
    {"tamanho": 3},
    {"tamanho": 2},
    {"tamanho": 1}
]

# Inicialização do tabuleiro vazio
def criar_tabuleiro():
    return [[[0 for _ in range(TAMANHO)] for _ in range(TAMANHO)] for _ in range(TAMANHO)]

# Verifica se uma posição é válida para colocar um navio
def pode_colocar(tabuleiro, x, y, z, dx, dy, dz, tamanho):
    for i in range(tamanho):
        nx, ny, nz = x + i*dx, y + i*dy, z + i*dz
        if not (0 <= nx < TAMANHO and 0 <= ny < TAMANHO and 0 <= nz < TAMANHO):
            return False
        if tabuleiro[nz][ny][nx] != 0:
            return False
    return True

# Coloca navios aleatoriamente
def colocar_navios(tabuleiro, navios):
    navio_id = 1
    for navio in navios:
        colocado = False
        while not colocado:
            x = random.randint(0, TAMANHO-1)
            y = random.randint(0, TAMANHO-1)
            z = random.randint(0, TAMANHO-1)
            direcoes = [(1,0,0), (0,1,0), (0,0,1)]
            dx, dy, dz = random.choice(direcoes)
            if pode_colocar(tabuleiro, x, y, z, dx, dy, dz, navio["tamanho"]):
                for i in range(navio["tamanho"]):
                    nx, ny, nz = x + i*dx, y + i*dy, z + i*dz
                    tabuleiro[nz][ny][nx] = navio_id
                navio["id"] = navio_id
                navio["hits"] = 0
                colocado = True
                navio_id += 1

# Verifica se o navio foi afundado
def verificar_afundado(tabuleiro, navios, navio_id):
    for navio in navios:
        if navio["id"] == navio_id:
            return navio["hits"] >= navio["tamanho"]
    return False

# Mostrar status
def mostrar_status(tiros):
    print(f"\nTentativas: {len(tiros)}")
    print("Tiros já feitos:")
    for t in sorted(tiros):
        print(f" - {t}")

# Jogo principal
def jogar():
    tabuleiro = criar_tabuleiro()
    colocar_navios(tabuleiro, NAVIOS)

    tiros_feitos = set()
    navios_afundados = set()

    print("Bem-vindo ao Batalha Naval 3D!")
    print(f"Tabuleiro {TAMANHO}x{TAMANHO}x{TAMANHO}")
    print(f"Total de navios: {len(NAVIOS)}\n")

    while len(navios_afundados) < len(NAVIOS):
        try:
            entrada = input("Digite coordenadas (x y z): ")
            if entrada.lower() in ['sair', 'exit', 'q']:
                print("Saindo do jogo.")
                break
            x, y, z = map(int, entrada.strip().split())
        except:
            print("Entrada inválida. Use o formato: x y z (ex: 2 3 1)")
            continue

        if not (0 <= x < TAMANHO and 0 <= y < TAMANHO and 0 <= z < TAMANHO):
            print("Coordenadas fora do tabuleiro.")
            continue

        if (x, y, z) in tiros_feitos:
            print("Você já atirou aqui.")
            continue

        tiros_feitos.add((x, y, z))
        valor = tabuleiro[z][y][x]

        if valor == 0:
            print("💧 Água!")
        else:
            print("🔥 Acertou um navio!")
            for navio in NAVIOS:
                if navio["id"] == valor:
                    navio["hits"] += 1
                    if verificar_afundado(tabuleiro, NAVIOS, valor):
                        print("💥 Você afundou um navio!")
                        navios_afundados.add(valor)
                    break
        mostrar_status(tiros_feitos)

    if len(navios_afundados) == len(NAVIOS):
        print("\n🏆 Parabéns! Você afundou todos os navios!")
        print(f"Número total de tiros: {len(tiros_feitos)}")

if __name__ == "__main__":
    jogar()
