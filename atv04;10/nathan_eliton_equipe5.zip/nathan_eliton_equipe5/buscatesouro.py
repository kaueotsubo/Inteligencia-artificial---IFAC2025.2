import random
from collections import deque
import os
import time


LINHAS = 9
COLUNAS = 10
OBSTACULO = 2
CAMINHO = 0


def gerar_labirinto(linhas, colunas):
    labirinto = [[random.choice([CAMINHO, OBSTACULO, CAMINHO]) for _ in range(colunas)] for _ in range(linhas)]
    return labirinto


def mostrar_labirinto(labirinto, jogador, tesouro, inimigo):
    os.system('cls' if os.name == 'nt' else 'clear')
    for i in range(len(labirinto)):
        linha = ""
        for j in range(len(labirinto[0])):
            if (i, j) == jogador:
                linha += "J "
            elif (i, j) == tesouro:
                linha += "T "
            elif (i, j) == inimigo:
                linha += "E "
            elif labirinto[i][j] == OBSTACULO:
                linha += "# "
            else:
                linha += ". "
        print(linha)
    print()


def bfs(labirinto, inicio, objetivo):
    fila = deque()
    fila.append((inicio, [inicio]))
    visitado = set()
    visitado.add(inicio)
    
    while fila:
        (x, y), caminho = fila.popleft()
        
        if (x, y) == objetivo:
            return caminho  
        
        for dx, dy in [(-1,0),(1,0),(0,-1),(0,1)]:  
            nx, ny = x + dx, y + dy
            if 0 <= nx < len(labirinto) and 0 <= ny < len(labirinto[0]):
                if labirinto[nx][ny] != OBSTACULO and (nx, ny) not in visitado:
                    visitado.add((nx, ny))
                    fila.append(((nx, ny), caminho + [(nx, ny)]))
    return None  

labirinto = gerar_labirinto(LINHAS, COLUNAS)
jogador = (0, 0)
tesouro = (LINHAS-1, COLUNAS-1)
inimigo = (LINHAS-1, 0)


while True:
    mostrar_labirinto(labirinto, jogador, tesouro, inimigo)
    
  
    caminho_jogador = bfs(labirinto, jogador, tesouro)
    if caminho_jogador is None:
        print("Tesouro inacessível!")
        break
    if len(caminho_jogador) > 1:
        jogador = caminho_jogador[1]

    
    caminho_inimigo = bfs(labirinto, inimigo, jogador)
    if caminho_inimigo is not None and len(caminho_inimigo) > 1:
        inimigo = caminho_inimigo[1]

    
    if jogador == tesouro:
        mostrar_labirinto(labirinto, jogador, tesouro, inimigo)
        print("Você encontrou o tesouro! 🏆")
        break
    if jogador == inimigo:
        mostrar_labirinto(labirinto, jogador, tesouro, inimigo)
        print("Você foi pego pelo inimigo! 💀")
        break

    time.sleep(0.5)
