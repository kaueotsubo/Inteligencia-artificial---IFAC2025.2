import heapq
import networkx as nx
import matplotlib.pyplot as plt

# O algoritmo A* não muda, ele apenas reage aos dados do mapa.
def a_star_search(graph, heuristic, start, goal):
    """
    Encontra o caminho de menor custo usando o algoritmo A*.
    Retorna o caminho (lista de nós) e o custo total (g).
    """
    priority_queue = [(0 + heuristic[start], 0, [start])]
    visited = set()

    while priority_queue:
        f, g, path = heapq.heappop(priority_queue)
        current_node = path[-1]

        if current_node in visited:
            continue
        
        if current_node == goal:
            return path, g

        visited.add(current_node)

        for neighbor, cost in graph.get(current_node, []):
            if neighbor not in visited:
                new_g = g + cost
                new_f = new_g + heuristic[neighbor]
                heapq.heappush(priority_queue, (new_f, new_g, path + [neighbor]))

    return None, 0

# NOVA FUNÇÃO: Para desenhar o grafo com o caminho destacado
def desenhar_grafo(graph_dict, caminho_otimo, titulo):
    """
    Cria e exibe um grafo visual usando NetworkX e Matplotlib.
    Destaca o caminho ótimo em vermelho.
    """
    G = nx.Graph()
    for no, vizinhos in graph_dict.items():
        for vizinho, custo in vizinhos:
            G.add_edge(no, vizinho, weight=custo)

    # Define uma posição fixa para os nós para que os dois grafos pareçam iguais
    pos = nx.spring_layout(G, seed=42)
    
    plt.figure(figsize=(10, 7))
    
    # Desenha todos os nós e arestas
    nx.draw(G, pos, with_labels=True, node_color='lightblue', node_size=700, font_size=16, font_weight='bold')
    
    # Adiciona os custos (pesos) nas arestas
    edge_labels = nx.get_edge_attributes(G, 'weight')
    nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels, font_size=14)
    
    # Destaca o caminho ótimo
    if caminho_otimo:
        path_edges = list(zip(caminho_otimo, caminho_otimo[1:]))
        nx.draw_networkx_edges(G, pos, edgelist=path_edges, edge_color='red', width=3)
        # Destaca os nós do caminho
        nx.draw_networkx_nodes(G, pos, nodelist=caminho_otimo, node_color='salmon')

    plt.title(titulo, size=20)
    plt.show()


# --- DADOS DO CENÁRIO ---

heuristic_to_g = {
    "A": 10, "B": 6, "C": 8, "D": 3, "F": 4, "G": 0
}

# --- Cenário 1: Mapa Original (Antes da Obra) ---

print("--- 1. Cenário Original (Antes da Obra na Via B->D) ---")
graph_original = {
    "A": [("B", 4), ("C", 3)], "B": [("D", 5)],
    "C": [("F", 8)], "D": [("G", 3)], "F": [("G", 4)]
}
original_path, original_cost = a_star_search(graph_original, heuristic_to_g, "A", "G")
if original_path:
    print(f"Rota ótima original: {' -> '.join(original_path)}")
    print(f"Custo total: {original_cost} minutos\n")
    # Desenha o primeiro grafo
    desenhar_grafo(graph_original, original_path, "Rota Original (Antes da Obra)")
else:
    print("Não foi possível encontrar uma rota.\n")

# --- Cenário 2: Mapa com Dificuldade Implementada (Obra na Via) ---

print("--- 2. Cenário com Dificuldade (Obra na Via B->D) ---")
graph_com_obra = {
    "A": [("B", 4), ("C", 3)], "B": [("D", 20)], # PENALIDADE APLICADA
    "C": [("F", 8)], "D": [("G", 3)], "F": [("G", 4)]
}
new_path, new_cost = a_star_search(graph_com_obra, heuristic_to_g, "A", "G")
if new_path:
    print(f"Nova rota ótima (desviando da obra): {' -> '.join(new_path)}")
    print(f"Novo custo total: {new_cost} minutos\n")
    # Desenha o segundo grafo
    desenhar_grafo(graph_com_obra, new_path, "Nova Rota Ótima (Com Obra na Via B->D)")
else:
    print("Não foi possível encontrar uma rota alternativa.\n")

# --- Análise do Resultado ---
print("="*50)
print("Análise do Resultado:")
print(f"A rota original '{' -> '.join(original_path)}' (custo {original_cost}) tornou-se inviável.")
print(f"O algoritmo reagiu à penalidade e encontrou a melhor alternativa: '{' -> '.join(new_path)}' com custo {new_cost}.")
print("="*50)