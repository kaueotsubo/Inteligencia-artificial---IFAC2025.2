import heapq

# Mapa de Marte (matriz [linha][coluna])
MAPA_MARTE = [
    ['1', 'S', '1', '0', '0', '0', '1'],
    ['1', '0', '0', '0', '1', '0', '1'],
    ['1', '3', '0', '1', '1', '0', '1'],
    ['1', '3', '0', '0', '1', '0', '1'],
    ['1', '0', 'G', '1', '1', '1', '1']
]

# Definição dos custos de energia por tipo de célula
CUSTO_ENERGIA = {
    '0': 1,   # Planície
    '3': 5,   # Terreno Acidentado
    '1': float('inf'), # Montanha (Intransponível)
    'S': 1,   # Ponto de Partida
    'G': 1    # Base de Chegada
}

# Direções de movimento (Cima, Baixo, Esquerda, Direita)
DIRECOES = [(-1, 0), (1, 0), (0, -1), (0, 1)]

# --- Funções Auxiliares ---

def encontrar_coordenadas(mapa, simbolo):
    """Encontra as coordenadas (linha, coluna) de um símbolo no mapa."""
    for r in range(len(mapa)):
        for c in range(len(mapa[0])):
            if mapa[r][c] == simbolo:
                return (r, c)
    return None

def heuristica_manhattan(atual, objetivo):
    """Calcula a Distância de Manhattan (h) entre duas células."""
    return abs(atual[0] - objetivo[0]) + abs(atual[1] - objetivo[1])

def calcular_custo_entrada(tipo_terreno):
    """Retorna o custo de energia para entrar na célula de destino."""
    return CUSTO_ENERGIA.get(tipo_terreno, float('inf'))

# --- 2. Algoritmo A* ---

def a_star_marte(mapa):
    """Executa a Busca A* para encontrar o caminho de menor custo de energia."""
    
    inicio_coord = encontrar_coordenadas(mapa, 'S')
    objetivo_coord = encontrar_coordenadas(mapa, 'G')
    
    if not inicio_coord or not objetivo_coord:
        return "Erro: Pontos de Partida (S) ou Chegada (G) não encontrados.", 0

    num_linhas = len(mapa)
    num_colunas = len(mapa[0])

    # Fila de Prioridade: (f, g, coordenada, caminho)
    # f = g + h; g = custo acumulado; caminho = lista de coordenadas
    # O custo inicial de g é 0 (custo para estar na célula 'S')
    fila_prioridade = [(heuristica_manhattan(inicio_coord, objetivo_coord), 
                        0, 
                        inicio_coord, 
                        [inicio_coord])]

    # Armazena o menor custo g encontrado até cada célula
    custo_g_min = {inicio_coord: 0}

    while fila_prioridade:
        f, g_atual, coord_atual, caminho_atual = heapq.heappop(fila_prioridade)
        
        r_atual, c_atual = coord_atual

        if coord_atual == objetivo_coord:
            # Retorna o caminho e o custo total de energia
            return caminho_atual, g_atual 

        # Explora vizinhos (mover para as 4 direções)
        for dr, dc in DIRECOES:
            r_viz, c_viz = r_atual + dr, c_atual + dc
            coord_viz = (r_viz, c_viz)

            # 1. Checa Limites do Mapa
            if not (0 <= r_viz < num_linhas and 0 <= c_viz < num_colunas):
                continue
            
            terreno_viz = mapa[r_viz][c_viz]

            # 2. Checa se é Montanha (Intransponível)
            custo_entrada = calcular_custo_entrada(terreno_viz)
            if custo_entrada == float('inf'):
                continue
            
            # 3. Calcula novos custos
            # O novo custo g inclui o custo para *entrar* na célula do vizinho
            novo_g = g_atual + custo_entrada 

            # 4. Checa Otimidade
            # Se já encontramos um caminho mais curto para o vizinho, descarte este
            if novo_g < custo_g_min.get(coord_viz, float('inf')):
                
                custo_g_min[coord_viz] = novo_g
                h_viz = heuristica_manhattan(coord_viz, objetivo_coord)
                novo_f = novo_g + h_viz
                
                # Prepara o novo estado para a fila de prioridade
                novo_caminho = caminho_atual + [coord_viz]
                heapq.heappush(fila_prioridade, (novo_f, novo_g, coord_viz, novo_caminho))

    return "Caminho não encontrado.", 0

# --- 3. Execução e Saída ---

caminho_coords, custo_total = a_star_marte(MAPA_MARTE)

# Formatação da saída
def formatar_caminho(caminho):
    """Converte lista de coordenadas para o formato (Linha, Coluna) e tipo de terreno."""
    if not isinstance(caminho, list):
        return caminho
    
    saida = []
    for r, c in caminho:
        terreno = MAPA_MARTE[r][c]
        saida.append(f"({r}, {c}) [{terreno}]")
    return " -> ".join(saida)

print("--- Missão do Rover 'Perseverança II' (Busca A*) ---")

if isinstance(caminho_coords, str):
    print(caminho_coords)
else:
    print("\n✅ Rota de Mínimo Consumo de Energia Encontrada!")
    print(f"Custo Total de Energia: {custo_total} pontos")
    print("\nDetalhes do Caminho (Linha, Coluna) [Terreno]:")
    print(formatar_caminho(caminho_coords))