import heapq 

# --- 1. Função de Busca A* Modificada para Otimidade ---
def a_star(grafo, heuristica, inicio, objetivo):
    """
    Algoritmo de Busca A* para encontrar o caminho de menor custo (tempo).
    Retorna o caminho e o custo total (tempo).
    """
    # Fila de prioridade: (f = g + h, g, caminho)
    fila = [(0 + heuristica.get(inicio, float('inf')), 0, [inicio])]
    # Dicionário para armazenar o menor custo g já encontrado até cada nó (Otimização)
    custo_g_min = {inicio: 0} 

    while fila:
        f, g, caminho = heapq.heappop(fila)
        no = caminho[-1]

        if no == objetivo:
            return caminho, g 

        # Poda: Se o custo g atual é maior que o melhor custo g já registrado, descarte o caminho.
        if g > custo_g_min.get(no, float('inf')):
            continue

        for vizinho, custo in grafo.get(no, []):
            novo_g = g + custo
            
            # Se encontramos um caminho mais curto (menor g) para o vizinho
            if novo_g < custo_g_min.get(vizinho, float('inf')):
                custo_g_min[vizinho] = novo_g
                # Calcula f = g + h
                novo_f = novo_g + heuristica.get(vizinho, float('inf'))
                
                # Adiciona o novo caminho à fila
                heapq.heappush(fila, (novo_f, novo_g, caminho + [vizinho]))

    return None, 0

# --- 2. Mapeamento do Grafo da Cidade e Heurísticas ---

# O mapa da imagem é modelado como um grafo bidirecional (custo = tempo em minutos)
grafo_cidade = {
    "Hosp": [("B", 3), ("A", 3)], # Hospital (Hosp)
    "A": [("Hosp", 3), ("E", 5)],
    "B": [("Hosp", 3), ("D", 3), ("E", 4)],
    "D": [("B", 3), ("Pac", 2), ("F", 1)],
    "E": [("A", 5), ("B", 4), ("F", 2)],
    "F": [("D", 1), ("E", 2)],
    "Pac": [("D", 2)] # Paciente (Pac)
}

# Heurística para IDA (Hosp -> Pac): Estimativa de tempo para o paciente
heuristica_ida = {
    "Hosp": 7, "A": 5, "B": 4, "D": 2, "E": 3, "F": 1, "Pac": 0 
}

# Heurística para VOLTA (Pac -> Hosp): Estimativa de tempo para o hospital
heuristica_volta = {
    "Hosp": 0, "A": 2, "B": 3, "D": 5, "E": 4, "F": 6, "Pac": 7 
}


# --- 3. FASE 1: Rota de IDA (Hospital -> Paciente) ---
print("--- FASE 1: Rota de IDA (Hospital -> Paciente) ---")

caminho_ida, tempo_ida = a_star(
    grafo=grafo_cidade, 
    heuristica=heuristica_ida, 
    inicio="Hosp", 
    objetivo="Pac"
)

print(f"Rota Ótima de IDA: {' -> '.join(caminho_ida)}")
print(f"Tempo Total (Ida): {tempo_ida} minutos")


# --- 4. FASE 2: Rota de VOLTA (Paciente -> Hospital) com Interdição de B ---

# 4.1. Criar o Grafo de Retorno e aplicar a Interdição da via B
# A interdição é modelada removendo todas as conexões de e para o nó 'B'
grafo_volta = {k: list(v) for k, v in grafo_cidade.items()}

# Remover conexões que saem de B
grafo_volta["B"] = [] 

# Remover as conexões que apontam PARA B (de Hosp, D e E)
for no in grafo_volta:
    grafo_volta[no] = [
        (vizinho, custo) for vizinho, custo in grafo_volta[no] if vizinho != "B"
    ]

# O nó B isolado não será mais um caminho de passagem, simulando a interdição.

print("\n--- FASE 2: Rota de VOLTA (Paciente -> Hospital) com Interdição de B ---")

caminho_volta, tempo_volta = a_star(
    grafo=grafo_volta, 
    heuristica=heuristica_volta, 
    inicio="Pac", 
    objetivo="Hosp"
)

print(f"Rota Ótima de VOLTA: {' -> '.join(caminho_volta)}")
print(f"Tempo Total (Volta): {tempo_volta} minutos")


# --- 5. RESUMO FINAL ---
print("\n--- RESUMO DO DESLOCAMENTO ---")
tempo_total_operacao = tempo_ida + tempo_volta
print(f"Tempo Total de Operação (Ida + Volta): {tempo_total_operacao} minutos")