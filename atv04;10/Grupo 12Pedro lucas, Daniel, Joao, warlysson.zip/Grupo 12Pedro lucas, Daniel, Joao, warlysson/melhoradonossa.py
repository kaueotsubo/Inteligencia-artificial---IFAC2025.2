import heapq 

# --- 1. Função de Busca A* ---
def a_star(grafo, heuristica, inicio, objetivo):
    """
    Algoritmo de Busca A* para encontrar o caminho de menor custo (tempo).
    Retorna o caminho e o custo total (tempo).
    """
    # Fila de prioridade: (f = g + h, g, caminho)
    f_inicial = 0 + heuristica.get(inicio, float('inf'))
    fila = [(f_inicial, 0, [inicio])]
    # Dicionário para armazenar o menor custo g já encontrado até cada nó (Otimização)
    custo_g_min = {inicio: 0} 

    while fila:
        f, g, caminho = heapq.heappop(fila)
        no = caminho[-1]

        if no == objetivo:
            return caminho, g 

        # Poda: Se o custo g atual é maior que o melhor custo g já registrado, descarte o caminho.
        if g > custo_g_min.get(no, float('inf')):
            continue

        for vizinho, custo in grafo.get(no, []):
            novo_g = g + custo
            
            # Se encontramos um caminho mais curto (menor g) para o vizinho
            if novo_g < custo_g_min.get(vizinho, float('inf')):
                custo_g_min[vizinho] = novo_g
                # Calcula f = g + h
                novo_f = novo_g + heuristica.get(vizinho, float('inf'))
                
                # Adiciona o novo caminho à fila
                heapq.heappush(fila, (novo_f, novo_g, caminho + [vizinho]))

    return None, 0

# --- 2. Mapeamento do Grafo e Heurísticas ---

# Grafo Original (bidirecional)
# E=Estoque, P=Ponto de Distribuição, H=Hospital, X,Y,Z=Passagem
grafo_cidade = {
    "E": [("X", 3), ("Z", 6)],
    "X": [("E", 3), ("Y", 5), ("H", 2)],
    "Y": [("X", 5), ("P", 5), ("H", 4)],
    "Z": [("E", 6), ("P", 2)],
    "H": [("X", 2), ("Y", 4)],
    "P": [("Y", 5), ("Z", 2)]
}

# Heurísticas (h): Estimativa de tempo para o objetivo
heuristica_ida = {
    "E": 9, "X": 6, "Y": 3, "Z": 4, "H": 8, "P": 0 
}

heuristica_volta = {
    "E": 0, "X": 5, "Y": 7, "Z": 5, "H": 2, "P": 9 
}


# --- 3. FASE 1: Rota de IDA (Estoque -> Ponto de Distribuição) ---
print("--- FASE 1: Rota de IDA (E -> P) ---")

caminho_ida, tempo_ida = a_star(
    grafo=grafo_cidade, 
    heuristica=heuristica_ida, 
    inicio="E", 
    objetivo="P"
)

print(f"Rota Ótima de IDA: {' -> '.join(caminho_ida)}")
print(f"Tempo Total (Ida): {tempo_ida} minutos")


# --- 4. FASE 2: Rota de VOLTA (Ponto de Distribuição -> Estoque) com Interdição ---

# 4.1. Criar o Grafo de Retorno e aplicar a Interdição
grafo_volta = {k: list(v) for k, v in grafo_cidade.items()}

# Interdição da via X <-> Y (custo 5).
# 1. Remover a conexão de X para Y
grafo_volta["X"] = [
    (vizinho, custo) for vizinho, custo in grafo_volta["X"] if vizinho != "Y"
]
# 2. Remover a conexão de Y para X
grafo_volta["Y"] = [
    (vizinho, custo) for vizinho, custo in grafo_volta["Y"] if vizinho != "X"
]

print("\n--- FASE 2: Rota de VOLTA (P -> E) com Interdição (X <-> Y) ---")

caminho_volta, tempo_volta = a_star(
    grafo=grafo_volta, 
    heuristica=heuristica_volta, 
    inicio="P", 
    objetivo="E"
)

print(f"Rota Ótima de VOLTA: {' -> '.join(caminho_volta)}")
print(f"Tempo Total (Volta): {tempo_volta} minutos")


# --- 5. RESUMO FINAL ---
print("\n--- RESUMO DO DESLOCAMENTO ---")
tempo_total_operacao = tempo_ida + tempo_volta
print(f"Tempo Total de Operação (Ida + Volta): {tempo_total_operacao} minutos")